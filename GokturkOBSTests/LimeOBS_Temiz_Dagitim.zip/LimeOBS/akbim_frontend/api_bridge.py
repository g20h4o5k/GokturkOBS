import json
import re
from bs4 import BeautifulSoup
import akbim_api

from pathlib import Path

# Bellek içi fotoğraf önbelleği
_CACHED_PHOTO_BYTES = None
CONFIG_FILE = Path(__file__).resolve().parent.parent / "akbim_config.json"


def get_saved_base_url():
    """Kayıtlı okul sunucu adresini döner, varsayılan https://tedemkolejiobs.com"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                url = cfg.get("base_url")
                if url:
                    return url.strip().rstrip("/")
        except Exception:
            pass
    return "https://tedemkolejiobs.com"


def set_base_url(url):
    """Okul sunucusu adresini ayarlar ve config'e kaydeder."""
    clean_url = url.strip().rstrip("/")
    if not clean_url.startswith("http://") and not clean_url.startswith("https://"):
        clean_url = f"https://{clean_url}"
    akbim_api.BASEURL = clean_url
    try:
        cfg = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        cfg["base_url"] = clean_url
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Config kaydetme hatası: {e}")
    return clean_url


def save_credentials(tc, password):
    """Beni Hatırla seçiliyse kimlik bilgilerini otomatik yenileme için güvenle yerel konfige yazar."""
    try:
        cfg = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        cfg["saved_creds"] = {"tc": tc, "password": password}
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Kimlik bilgisi kaydetme hatası: {e}")


def get_saved_credentials():
    """Kayıtlı kimlik bilgilerini döner."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                return cfg.get("saved_creds")
        except Exception:
            pass
    return None


def clear_saved_credentials():
    """Oturum kapatıldığında kayıtlı bilgileri temizler."""
    try:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            if "saved_creds" in cfg:
                del cfg["saved_creds"]
                with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                    json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def ensure_valid_session():
    """Oturum süresi dolmuşsa kayıtlı kimlik bilgileriyle otomatik olarak arka planda yeniden giriş yapar."""
    try:
        if akbim_api.check_session():
            return True
        creds = get_saved_credentials()
        if creds and creds.get("tc") and creds.get("password"):
            res = akbim_api.login(creds["tc"], creds["password"])
            if res.get("success"):
                akbim_api.save_session()
                return True
    except Exception as e:
        print(f"Otomatik oturum yenileme hatası: {e}")
    return False


def get_saved_theme():
    """Kayıtlı tema modunu döner: 'dark', 'light' veya 'liquid' (varsayılan: 'liquid')"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                theme = cfg.get("theme")
                if theme in ["dark", "light", "liquid"]:
                    return theme
        except Exception:
            pass
    return "liquid"



def save_theme(theme_name):
    """Tema tercihini kaydeder."""
    try:
        cfg = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        cfg["theme"] = theme_name
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Tema ayarı kaydetme hatası: {e}")


# Başlangıçta kayıtlı URL'yi ayarla
akbim_api.BASEURL = get_saved_base_url()


# Aktif görüntüleme modu (Veli oturumunda veli özeti veya öğrenci detay modu)
_CURRENT_VIEW_MODE = None  # None (otomatik), 'parent' veya 'student'


def get_current_view_mode():
    return "student"


def set_current_view_mode(mode):
    global _CURRENT_VIEW_MODE
    _CURRENT_VIEW_MODE = mode
    try:
        cfg = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        cfg["view_mode"] = mode
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"View mode kaydetme hatası: {e}")


def clear_cache():
    global _CACHED_PHOTO_BYTES, _CURRENT_VIEW_MODE
    _CACHED_PHOTO_BYTES = None
    _CURRENT_VIEW_MODE = None



def get_school_metadata():
    """Bağlı okul adını ve aktif eğitim dönemini tespit eder."""
    school_name = "Akbim OBS"
    academic_term = "2026-2027"

    try:
        nav = get_nav_metadata()
        brand_name = nav.get("raw", {}).get("brand", {}).get("name", "")
        if brand_name:
            # "Tedem Koleji | Online Bilgi Sistemi" -> "Tedem Koleji"
            if "|" in brand_name:
                school_name = brand_name.split("|")[0].strip()
            elif "-" in brand_name:
                school_name = brand_name.split("-")[0].strip()
            else:
                school_name = brand_name.strip()
        else:
            # Domain adından çıkar
            domain = akbim_api.BASEURL.replace("https://", "").replace("http://", "").split("/")[0]
            clean_dom = domain.replace("obs.", "").replace("obs", "")
            school_name = clean_dom.split(".")[0].capitalize()

        # Dönem tespiti: index exam tarihlerinden veya güncel yıldan
        from datetime import datetime
        now_year = datetime.now().year
        academic_term = f"{now_year}-{now_year+1}"
    except Exception as e:
        print(f"Okul metadata tespit hatası: {e}")

    return {
        "school_name": school_name,
        "academic_term": academic_term
    }


def get_nav_metadata():
    """menuLoader.php'den aktif oturumun rolünü ('parent'/'student') ve 'base' yolunu çeker."""
    try:
        # 1. Öncelik: menuLoader.php üzerinden kontrol (en kesin yöntem)
        res = akbim_api.session.get(f"{akbim_api.BASEURL}/require/menuLoader.php")
        if "window.obsNavData = " in res.text:
            json_text = res.text.split("window.obsNavData = ", 1)[1].split("};", 1)[0] + "}"
            data = json.loads(json_text)
            key = data.get("key")
            brand_sub = data.get("brand", {}).get("sub", "").lower()
            user_sub = data.get("user", {}).get("sub", "").lower()
            if key == "parent" or "veli" in brand_sub or "veli" in user_sub:
                key = "parent"
            else:
                key = "student"
            base = data.get("base", f"pages/{key}/")
            return {"key": key, "base": base, "raw": data}

        # 2. Öncelik: Sayfa bazlı doğrulama
        for candidate_key in ["student", "parent"]:
            chk = akbim_api.session.get(f"{akbim_api.BASEURL}/pages/{candidate_key}/profile.php")
            if chk.ok and "Kullanıcı Profili" in chk.text and "login.php" not in chk.url:
                return {"key": candidate_key, "base": f"pages/{candidate_key}/", "raw": {}}
    except Exception as e:
        print(f"menuLoader okuma hatası: {e}")
    return {"key": "student", "base": "pages/student/", "raw": {}}


def get_adaptive_index_data():
    """Hem Veli (pages/parent/) hem de Öğrenci (pages/student/) için doğru indexAction endpoint'ine istek atar."""
    # akbim_api.load_index()'i de doğrudan kullan
    try:
        data = akbim_api.load_index()
        if data and data.get("success") and "data" in data:
            return data
    except Exception:
        pass

    nav = get_nav_metadata()
    base = nav.get("base", "pages/student/").strip("/")

    candidate_urls = [
        f"{akbim_api.BASEURL}/{base}/require/indexAction.php",
        f"{akbim_api.BASEURL}/pages/student/require/indexAction.php",
        f"{akbim_api.BASEURL}/pages/parent/require/indexAction.php",
    ]

    seen = set()
    for url in candidate_urls:
        if url in seen:
            continue
        seen.add(url)

        try:
            res = akbim_api.session.post(
                url,
                data={"request": "loadIndex"},
                headers={"X-Requested-With": "XMLHttpRequest"}
            )
            if res.ok:
                data = res.json()
                if data.get("success") and "data" in data:
                    return data
        except Exception:
            continue

    return {"success": False, "data": {"examList": [], "announcementList": [], "eventList": [], "lessonSchedule": {"data": {}}}}



def fetch_student_photo_bytes():
    """Öğrenci vesikalık fotoğrafını çeker ve ikili (bytes) olarak döner."""
    global _CACHED_PHOTO_BYTES
    if _CACHED_PHOTO_BYTES:
        return _CACHED_PHOTO_BYTES

    # 1. Öncelik: profile.php HTML içerisindeki <img> etiketi
    candidate_profile_pages = [
        f"{akbim_api.BASEURL}/pages/student/profile.php",
        f"{akbim_api.BASEURL}/pages/parent/profile.php"
    ]

    headers = {
        "Accept": "image/avif,image/webp,image/png,image/jpeg,*/*;q=0.8",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64)",
        "Referer": f"{akbim_api.BASEURL}/pages/student/profile.php"
    }

    for p_url in candidate_profile_pages:
        try:
            p_res = akbim_api.session.get(p_url)
            if p_res.ok and "login.php" not in p_res.url:
                # Regex 1: studentPhoto.php içeren img etiketleri
                match = re.search(r'<img\b[^>]*\bsrc\s*=\s*["\']([^"\']*studentPhoto\.php[^"\']*)["\']', p_res.text, re.IGNORECASE)
                if not match:
                    # Regex 2: Herhangi bir photo / vesikalık / profil img src'si
                    match = re.search(r'<img\b[^>]*\bsrc\s*=\s*["\']([^"\']*(?:studentPhoto|photo|resim)[^"\']*)["\']', p_res.text, re.IGNORECASE)
                
                if match:
                    rel_src = match.group(1).lstrip("/")
                    full_url = rel_src if rel_src.startswith("http") else f"{akbim_api.BASEURL}/{rel_src}"
                    img_res = akbim_api.session.get(full_url, headers=headers)
                    if img_res.ok and len(img_res.content) > 100:
                        _CACHED_PHOTO_BYTES = img_res.content
                        return _CACHED_PHOTO_BYTES
        except Exception as e:
            print(f"HTML fotoğraf çekme hatası: {e}")

    # 2. Öncelik: Doğrudan bilinen endpoint'ler
    direct_photo_urls = [
        f"{akbim_api.BASEURL}/pages/student/require/studentPhoto.php",
        f"{akbim_api.BASEURL}/pages/student/studentPhoto.php",
        f"{akbim_api.BASEURL}/require/studentPhoto.php"
    ]
    for d_url in direct_photo_urls:
        try:
            d_res = akbim_api.session.get(d_url, headers=headers)
            if d_res.ok and len(d_res.content) > 100 and "text/html" not in d_res.headers.get("Content-Type", ""):
                _CACHED_PHOTO_BYTES = d_res.content
                return _CACHED_PHOTO_BYTES
        except Exception:
            pass

    # 3. Öncelik: menuLoader.php içerisindeki user.photo alanı
    try:
        nav = get_nav_metadata()
        photo_rel = nav.get("raw", {}).get("user", {}).get("photo")
        if photo_rel:
            full_url = photo_rel if photo_rel.startswith("http") else f"{akbim_api.BASEURL}/{photo_rel.lstrip('/')}"
            img_res = akbim_api.session.get(full_url, headers=headers)
            if img_res.ok and len(img_res.content) > 100:
                _CACHED_PHOTO_BYTES = img_res.content
                return _CACHED_PHOTO_BYTES
    except Exception as e:
        print(f"menuLoader fotoğraf çekme hatası: {e}")

    return None


def get_adaptive_profile_data():
    """Hem Veli hem Öğrenci hesaplarının profil bilgilerini ve vesikalık fotoğrafını çözer."""
    nav = get_nav_metadata()
    role_key = nav.get("key", "student")
    is_parent = (role_key == "parent")

    profile_result = {
        "role": "Veli" if is_parent else "Öğrenci",
        "student_name": None,
        "student_class": None,
        "student_no": None,
        "student_prog": None,
        "parent_name": None,
        "photo_bytes": None,
        "raw_fields": {}
    }

    # 1. Öncelik: akbim_api.get_student_profile() çağrısı ile student profilini al
    try:
        api_profile = akbim_api.get_student_profile()
        if isinstance(api_profile, dict) and not api_profile.get("error"):
            for k, v in api_profile.items():
                profile_result["raw_fields"][k] = v
                k_lower = k.lower()
                if "veli" in k_lower and ("isim" in k_lower or "ad" in k_lower):
                    profile_result["parent_name"] = v
                elif "isim" in k_lower or "ad soyad" in k_lower:
                    if not profile_result["student_name"]:
                        profile_result["student_name"] = v
                elif "sınıf" in k_lower:
                    profile_result["student_class"] = v
                elif "no" in k_lower or "numara" in k_lower:
                    profile_result["student_no"] = v
                elif "program" in k_lower:
                    profile_result["student_prog"] = v
    except Exception as e:
        print(f"akbim_api.get_student_profile hatası: {e}")

    # 2. Öncelik: Sayfa bazlı tarama
    # Veli oturumunda pages/parent/profile.php içinde hem Öğrenci hem Veli bilgileri yer alır!
    candidate_urls = [
        f"{akbim_api.BASEURL}/pages/parent/profile.php",
        f"{akbim_api.BASEURL}/pages/student/profile.php",
    ] if is_parent else [
        f"{akbim_api.BASEURL}/pages/student/profile.php",
        f"{akbim_api.BASEURL}/pages/parent/profile.php",
    ]

    seen = set()
    for url in candidate_urls:
        if profile_result["student_name"] and profile_result["student_class"]:
            break
        if url in seen:
            continue
        seen.add(url)

        try:
            res = akbim_api.session.get(url)
            if not res.ok or "login.php" in res.url:
                continue

            soup = BeautifulSoup(res.text, "html.parser")

            # dl-horizontal bloklarını doğrudan tara
            dl_blocks = soup.find_all("dl", class_="dl-horizontal")
            for dl in dl_blocks:
                prev_h = dl.find_previous(["h1", "h2", "h3", "h4", "h5", "header"])
                h_text = prev_h.get_text(" ", strip=True).lower() if prev_h else ""
                is_student_block = ("öğrenci" in h_text)
                is_parent_block = ("veli" in h_text)

                for dt in dl.find_all("dt"):
                    dd = dt.find_next_sibling("dd")
                    if not dd:
                        continue
                    label = dt.get_text(strip=True)
                    val = dd.get_text(strip=True)
                    
                    if is_student_block or (not is_parent_block and not profile_result["student_name"]):
                        profile_result["raw_fields"][f"student_{label}"] = val
                        if label == "İsim Soyisim" and not profile_result["student_name"]:
                            profile_result["student_name"] = val
                        elif label == "Sınıf Kodu" and not profile_result["student_class"]:
                            profile_result["student_class"] = val
                        elif ("Numara" in label or "No" in label) and not profile_result["student_no"]:
                            profile_result["student_no"] = val
                        elif "Program" in label and not profile_result["student_prog"]:
                            profile_result["student_prog"] = val
                    elif is_parent_block:
                        profile_result["raw_fields"][f"parent_{label}"] = val
                        if label == "İsim Soyisim":
                            profile_result["parent_name"] = val

            # Genel dt/dd araması fallback
            if not profile_result["student_name"]:
                for dt in soup.find_all("dt"):
                    label = dt.get_text(strip=True)
                    dd = dt.find_next_sibling("dd")
                    if not dd:
                        continue
                    val = dd.get_text(strip=True)
                    if label == "İsim Soyisim":
                        profile_result["student_name"] = val
                    elif label == "Sınıf Kodu":
                        profile_result["student_class"] = val
                    elif "Numara" in label or "No" in label:
                        profile_result["student_no"] = val
        except Exception as e:
            print(f"Profil sayfası kazıma hatası ({url}): {e}")
            continue

    # 3. Öncelik: nav metadata'sındaki user.name
    user_info = nav.get("raw", {}).get("user", {})
    if is_parent:
        if not profile_result["parent_name"] and user_info.get("name"):
            profile_result["parent_name"] = user_info["name"]
    else:
        if not profile_result["student_name"] and user_info.get("name"):
            profile_result["student_name"] = user_info["name"]

    # Fotoğrafı çek
    profile_result["photo_bytes"] = fetch_student_photo_bytes()

    return profile_result


def fetch_exam_report(exam_id, exam_type="SBS"):
    """Belirli bir sınavın karnesini, netlerini ve konu analizini Akbim'den çeker."""
    profile = get_adaptive_profile_data()
    stu_no = profile.get("student_no") or "20669"
    class_id = profile.get("student_class") or "K-7-E"

    endpoints = [
        f"{akbim_api.BASEURL}/pages/student/require/examDashboard.php",
        f"{akbim_api.BASEURL}/pages/parent/require/examDashboard.php",
    ]

    payload = {
        "request": "getSchoolReport",
        "examType": exam_type or "SBS",
        "examId": exam_id,
        "stuNo": stu_no,
        "classId": class_id,
    }

    for ep in endpoints:
        try:
            res = akbim_api.session.post(ep, data=payload)
            if res.ok:
                data = res.json()
                if data.get("success"):
                    return data
        except Exception as e:
            print(f"Karne çekme hatası ({ep}): {e}")

    return None


def fetch_food_list_data():
    """Yemek listesi hash'ini ve binary PDF içeriğini çeker."""
    if not akbim_api.check_session():
        if not akbim_api.ensure_login():
            return {"success": False, "hash": None, "pdf_bytes": None}

    nav = get_nav_metadata()
    base = nav.get("base", "pages/student/").strip("/")
    candidate_urls = [
        f"{akbim_api.BASEURL}/{base}/require/foodListAction.php",
        f"{akbim_api.BASEURL}/pages/student/require/foodListAction.php",
    ]

    seen = set()
    for action_url in candidate_urls:
        if action_url in seen:
            continue
        seen.add(action_url)

        try:
            res = akbim_api.session.post(
                action_url,
                data={"request": "get-food-list"},
                headers={"X-Requested-With": "XMLHttpRequest"}
            )
            if res.ok:
                data = res.json()
                f_hash = data.get("hash")
                if f_hash:
                    dl_res = akbim_api.session.get(
                        f"{akbim_api.BASEURL}/download.php",
                        params={"file": f_hash, "view": ""}
                    )
                    if dl_res.ok and len(dl_res.content) > 100:
                        return {
                            "success": True,
                            "hash": f_hash,
                            "pdf_bytes": dl_res.content
                        }
        except Exception:
            continue

    return {"success": False, "hash": None, "pdf_bytes": None}


def change_user_password(old_password, new_password, new_password_re):
    """
    Akbim OBS kullanıcısının şifresini değiştirir.
    pages/student/require/changePassword.php veya pages/parent/require/changePassword.php
    Dönüş formatı: {"success": bool, "message": str}
    """
    if not old_password or not new_password or not new_password_re:
        return {"success": False, "message": "Boş alan bıraktınız."}

    if len(new_password) < 6:
        return {"success": False, "message": "Yeni şifreniz en az 6 haneli olmalıdır."}

    if len(new_password) > 30:
        return {"success": False, "message": "Yeni şifreniz en fazla 30 haneli olabilir."}

    if new_password != new_password_re:
        return {"success": False, "message": "Şifreleriniz eşleşmiyor."}

    if old_password == new_password:
        return {"success": False, "message": "Yeni şifreniz mevcut olanla aynı."}

    nav = get_nav_metadata()
    role_base = nav.get("base", "pages/student/").strip("/")

    candidate_endpoints = [
        f"{akbim_api.BASEURL}/{role_base}/require/changePassword.php",
        f"{akbim_api.BASEURL}/pages/student/require/changePassword.php",
        f"{akbim_api.BASEURL}/pages/parent/require/changePassword.php",
    ]

    payload = {
        "password": old_password,
        "passwordNew": new_password,
        "passwordReNew": new_password_re,
        "request": "editPassword",
    }

    seen = set()
    for ep in candidate_endpoints:
        if ep in seen:
            continue
        seen.add(ep)

        try:
            res = akbim_api.session.post(ep, data=payload)
            if res.ok:
                resp_text = res.text.strip()
                if resp_text == "success":
                    return {"success": True, "message": "Şifreniz başarıyla değiştirildi."}
                elif resp_text == "wrongPassword":
                    return {"success": False, "message": "Mevcut şifrenizi yanlış girdiniz."}
                elif resp_text == "requestDenied":
                    return {"success": False, "message": "Ancak 1 saatte 1 kere şifre değişikliği yapabilirsiniz."}
                elif resp_text == "shortPass":
                    return {"success": False, "message": "Yeni şifreniz en az 6 haneli olmalıdır."}
                elif resp_text == "longPass":
                    return {"success": False, "message": "Yeni şifreniz en fazla 30 haneli olabilir."}
                elif resp_text == "notEqual":
                    return {"success": False, "message": "Şifreleriniz eşleşmiyor."}
                elif resp_text == "samePass":
                    return {"success": False, "message": "Yeni şifreniz mevcut olanla aynı."}
                elif resp_text == "empty":
                    return {"success": False, "message": "Boş alan bıraktınız."}
                else:
                    return {"success": False, "message": f"Sistem yanıtı: {resp_text}"}
        except Exception as e:
            print(f"Şifre değiştirme isteği hatası ({ep}): {e}")
            continue

    return {"success": False, "message": "Şifre değiştirme servisine ulaşılamadı."}


def fetch_teachers_data():
    """Öğrencinin dersine giren öğretmenlerin listesini ve fotoğraflarını çeker."""
    nav = get_nav_metadata()
    role_base = nav.get("base", "pages/student/").strip("/")
    
    candidate_endpoints = [
        f"{akbim_api.BASEURL}/{role_base}/require/teacherAction.php",
        f"{akbim_api.BASEURL}/pages/student/require/teacherAction.php",
    ]

    for attempt in range(2):
        for ep in candidate_endpoints:
            try:
                res = akbim_api.session.post(
                    ep,
                    data={"request": "loadMyOwnTeachers"},
                    headers={"X-Requested-With": "XMLHttpRequest"}
                )
                if res.ok and res.text.strip().startswith("{"):
                    data = res.json()
                    if data.get("success"):
                        return data.get("data", [])
            except Exception:
                pass

        if attempt == 0:
            if not ensure_valid_session():
                break

    return []


def fetch_events_data():
    """Okul etkinlikleri listesini çeker."""
    index_data = get_adaptive_index_data()
    return index_data.get("data", {}).get("eventList", []) or []


def fetch_mail_content(mail_id):
    """
    Belirli bir postanın tam metnini ve ek dosya bilgilerini çeker (oturum düşerse otomatik yeniler).
    POST /obsapi/mail/getMailContent with {"mailId": mail_id}
    """
    for attempt in range(2):
        try:
            res = akbim_api.session.post(
                f"{akbim_api.BASEURL}/obsapi/mail/getMailContent",
                data={"mailId": mail_id}
            )
            if res.ok:
                data = res.json()
                if data.get("success"):
                    return data.get("data", {}).get("mailContent", {})
                elif data.get("error") == "Login required" and attempt == 0:
                    if ensure_valid_session():
                        continue
        except Exception as e:
            print(f"Mail içeriği çekme hatası: {e}")
            break
    return None


def search_mail_receivers(query):
    """Öğretmen veya okul yöneticisi arar."""
    try:
        return akbim_api.search_receivers(query)
    except Exception as e:
        print(f"Alıcı arama köprüsü hatası: {e}")
        return []


def send_mail_message(title, content, receiver_user_type, receiver_user_id, reply_id=""):
    """Öğretmene veya yöneticiye mesaj gönderir."""
    try:
        return akbim_api.send_mail(
            title=title,
            content=content,
            receiver_user_type=receiver_user_type,
            receiver_user_id=receiver_user_id,
            reply_id=reply_id
        )
    except Exception as e:
        return {"success": False, "msg": str(e)}



def fetch_homeworks_list():
    """Ödevler listesini çeker (akbim_api.homeworks() kullanarak)."""
    try:
        res = akbim_api.homeworks()
        if isinstance(res, dict) and res.get("success"):
            return res.get("data", [])
        elif isinstance(res, list):
            return res
    except Exception as e:
        print(f"Ödevler listesi çekme hatası: {e}")
    return []


def fetch_homework_detail(homework_id):
    """Belirli bir ödevin detaylarını ve açıklamalarını çeker (oturum düşerse otomatik yeniler)."""
    for attempt in range(2):
        try:
            res = akbim_api.session.get(f"{akbim_api.BASEURL}/obsapi/homework/getHomeworkDetail?id={homework_id}")
            if res.ok:
                data = res.json()
                if data.get("success"):
                    return data.get("data", {})
                elif data.get("error") == "Login required" and attempt == 0:
                    if ensure_valid_session():
                        continue
        except Exception as e:
            print(f"Ödev detay çekme hatası: {e}")
            break
    return None


def download_homework_attachment(homework_id, file_id, file_type="attachFiles"):
    """
    Ödev ek dosyasını token alıp indirir ve (dosya_içeriği_bytes, hata_mesajı) döner.
    """
    try:
        params = {
            "homeworkId": homework_id,
            "fileId": file_id,
            "fileType": file_type
        }
        token_res = akbim_api.session.get(f"{akbim_api.BASEURL}/obsapi/homework/getHomeworkFileToken", params=params)
        if not token_res.ok:
            return None, "Token isteği başarısız oldu."
        
        token_data = token_res.json()
        token = token_data.get("token")
        if not token:
            return None, "Dosya indirme yetki jetonu (token) alınamadı."

        dl_url = f"{akbim_api.BASEURL}/obsapi/public/downloadFileByToken?f={token}"
        dl_res = akbim_api.session.get(dl_url)
        if dl_res.ok and len(dl_res.content) > 0:
            return dl_res.content, None
        return None, "Dosya sunucudan indirilemedi."
    except Exception as e:
        return None, str(e)


def fetch_attendance_data():
    """Öğrencinin devamsızlık özetini ve listesini çeker."""
    nav = get_nav_metadata()
    role_base = nav.get("base", "pages/student/").strip("/")
    endpoint = f"{akbim_api.BASEURL}/{role_base}/require/attendanceDashboard.php"

    for attempt in range(2):
        try:
            init_res = akbim_api.session.post(
                endpoint,
                data={"request": "load-attendance-initial-data"},
                headers={"X-Requested-With": "XMLHttpRequest"}
            )
            if init_res.ok and init_res.text.strip().startswith("{"):
                init_data = init_res.json()
                periods = init_data.get("periods", [])
                period_id = periods[0].get("id") if periods else None
                
                # Devamsızlık detay listesini çek (varsa)
                absence_list = []
                if period_id is not None:
                    list_res = akbim_api.session.post(
                        endpoint,
                        data={"request": "get-attendance-graph-7", "periodId": period_id},
                        headers={"X-Requested-With": "XMLHttpRequest"}
                    )
                    if list_res.ok and list_res.text.strip().startswith("{"):
                        absence_list = list_res.json().get("list", []) or []

                return {
                    "success": True,
                    "periods": periods,
                    "charts": init_data.get("charts", {}),
                    "absence_list": absence_list
                }
        except Exception as e:
            pass

        if attempt == 0:
            if not ensure_valid_session():
                break

    return {"success": False, "periods": [], "charts": {}, "absence_list": []}


def get_student_general_report():
    """
    Veli Paneli için kapsamlı Öğrenci Durum Raporunu çeker.
    (Deneme sınavları, DAS puanları, ders bazlı ödev tamamlama sayıları, devamsızlık ve öğretmen bilgileri)
    """
    payload = {
        "request": "getStudentGeneralList",
        "studentList": 0,
        "teacherInfo": 2,
        "exams": 2,
        "dbs": 2,
        "attendance": 2,
        "exam": 2,
        "homework": 2,
        "course1": 2,
        "course2": 2,
        "library": 2
    }
    endpoints = [
        f"{akbim_api.BASEURL}/pages/student/require/studentGeneralList.php",
        f"{akbim_api.BASEURL}/pages/parent/require/studentGeneralList.php"
    ]
    for attempt in range(2):
        for ep in endpoints:
            try:
                res = akbim_api.session.post(ep, data=payload, headers={"X-Requested-With": "XMLHttpRequest"})
                if res.ok and res.text.strip().startswith("{"):
                    data = res.json()
                    if data.get("success"):
                        students = data.get("data", {}).get("students", [])
                        if students:
                            return students[0]
            except Exception:
                pass
        if attempt == 0:
            if not ensure_valid_session():
                break

    return None


def open_file_external(file_path):
    """
    Çapraz platform (macOS, Linux, Windows) harici dosya / PDF açıcı.
    macOS: 'open'
    Linux: 'xdg-open'
    Windows: 'os.startfile'
    """
    import sys
    import subprocess
    import os

    try:
        p_str = str(file_path)
        if sys.platform == "darwin":
            subprocess.Popen(["open", p_str])
        elif sys.platform.startswith("win"):
            os.startfile(p_str)
        else:
            subprocess.Popen(["xdg-open", p_str])
        return True
    except Exception as e:
        print(f"Harici dosya açma hatası ({file_path}): {e}")
        return False








