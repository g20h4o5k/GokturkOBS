import os
import sys
import threading
from pathlib import Path

# Add project root to sys.path so we can import backend in read-only mode
ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib, Gio, Gdk

GLib.set_prgname("com.kagan.limeobs")
GLib.set_application_name("LimeOBS")

import akbim_api
from views.login_view import LoginView
from views.home_view import HomeView
from views.schedule_view import ScheduleView
from views.exams_view import ExamsView
from views.announcements_view import AnnouncementsView
from views.profile_view import ProfileView
from views.messages_view import MessagesView
from views.food_list_view import FoodListView
from views.teachers_view import TeachersView
from views.homework_view import HomeworkView
from views.attendance_view import AttendanceView
from views.command_palette_dialog import CommandPaletteDialog
from api_bridge import get_adaptive_profile_data, clear_cache, get_school_metadata, get_saved_theme, save_theme


class AkbimApplication(Adw.Application):
    def __init__(self):
        super().__init__(
            application_id="com.kagan.limeobs",
            flags=Gio.ApplicationFlags.FLAGS_NONE
        )
        self.window = None

    def do_activate(self):
        self.load_icons()
        if not self.window:
            self.load_css()
            self.window = AkbimMainWindow(self)
        
        saved_theme = get_saved_theme()
        self.apply_theme(saved_theme)
        self.window.present()

    def apply_theme(self, theme_name):
        style_mgr = Adw.StyleManager.get_default()
        if theme_name == "light":
            style_mgr.set_color_scheme(Adw.ColorScheme.FORCE_LIGHT)
            if self.window:
                self.window.remove_css_class("theme-liquid")
                self.window.remove_css_class("theme-dark")
                self.window.add_css_class("theme-light")
        elif theme_name == "dark":
            style_mgr.set_color_scheme(Adw.ColorScheme.FORCE_DARK)
            if self.window:
                self.window.remove_css_class("theme-liquid")
                self.window.remove_css_class("theme-light")
                self.window.add_css_class("theme-dark")
        else: # "liquid"
            style_mgr.set_color_scheme(Adw.ColorScheme.FORCE_DARK)
            if self.window:
                self.window.remove_css_class("theme-dark")
                self.window.remove_css_class("theme-light")
                self.window.add_css_class("theme-liquid")
        save_theme(theme_name)

    def load_icons(self):
        frontend_dir = Path(__file__).parent
        display = Gdk.Display.get_default()
        if display:
            icon_theme = Gtk.IconTheme.get_for_display(display)
            icon_theme.add_search_path(str(frontend_dir))

    def load_css(self):
        css_path = Path(__file__).parent / "style.css"
        if css_path.exists():
            provider = Gtk.CssProvider()
            provider.load_from_path(str(css_path))
            Gtk.StyleContext.add_provider_for_display(
                Gdk.Display.get_default(),
                provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )


class AkbimMainWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.set_title("LimeOBS — Öğrenci & Veli Paneli")
        self.set_icon_name("com.kagan.limeobs")
        self.set_default_size(1080, 740)

        # Ana Ekran Yöneticisi (Stack: Giriş Sayfası vs Ana Panel)
        self.main_stack = Gtk.Stack()
        self.main_stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)

        # 1. Giriş Sayfası (LoginView)
        self.login_view = LoginView(on_login_success=self.on_login_successful)
        self.main_stack.add_named(self.login_view, "login")

        # 2. Ana Dashboard Sayfası
        self.dashboard_widget = self.build_dashboard()
        self.main_stack.add_named(self.dashboard_widget, "dashboard")

        self.set_content(self.main_stack)

        # ⌨️ Genel Klavye Kısayolları (Ctrl + K -> Quick Launcher)
        key_controller = Gtk.EventControllerKey()
        key_controller.connect("key-pressed", self.on_window_key_pressed)
        self.add_controller(key_controller)

        # Oturum Kontrolü ve Başlangıç Ekranı
        self.check_initial_session()

    def on_window_key_pressed(self, controller, keyval, keycode, state):
        # macOS için Command (Meta/Super) veya Linux/Windows için Ctrl kontrolü
        is_ctrl_or_cmd = bool(
            (state & Gdk.ModifierType.CONTROL_MASK) or
            (state & Gdk.ModifierType.META_MASK) or
            (state & Gdk.ModifierType.SUPER_MASK)
        )
        if is_ctrl_or_cmd and keyval in [Gdk.KEY_k, Gdk.KEY_K]:
            self.open_command_palette()
            return True
        return False

    def open_command_palette(self):
        dialog = CommandPaletteDialog(
            parent_window=self,
            on_navigate=self.navigate_to_tab
        )
        dialog.present()

    def check_initial_session(self):
        def worker():
            akbim_api.load_session()
            is_valid = akbim_api.check_session()
            if not is_valid:
                from api_bridge import ensure_valid_session
                is_valid = ensure_valid_session()

            if is_valid:
                GLib.idle_add(self.on_login_successful)
            else:
                GLib.idle_add(lambda: self.main_stack.set_visible_child_name("login"))

        threading.Thread(target=worker, daemon=True).start()

    def build_dashboard(self):
        self.split_view = Adw.NavigationSplitView()
        self.split_view.set_min_sidebar_width(240)
        self.split_view.set_max_sidebar_width(300)

        # Sidebar (Sol Menü)
        self.sidebar_page = Adw.NavigationPage.new(self.build_sidebar(), "Menü")
        self.split_view.set_sidebar(self.sidebar_page)

        # İçerik Alanı (ViewStack)
        self.stack = Adw.ViewStack()
        
        self.home_view = HomeView(
            on_navigate_tab=self.navigate_to_tab
        )
        self.schedule_view = ScheduleView()
        self.exams_view = ExamsView()
        self.food_view = FoodListView()
        self.homework_view = HomeworkView()
        self.attendance_view = AttendanceView()
        self.announcements_view = AnnouncementsView()
        self.teachers_view = TeachersView()
        self.messages_view = MessagesView()
        self.profile_view = ProfileView(on_logout=self.on_logout_clicked)

        self.stack.add_titled_with_icon(self.home_view, "home", "Anasayfa", "user-home-symbolic")
        self.stack.add_titled_with_icon(self.schedule_view, "schedule", "Dersler", "appointment-soon-symbolic")
        self.stack.add_titled_with_icon(self.attendance_view, "attendance", "Devamsızlık", "user-available-symbolic")
        self.stack.add_titled_with_icon(self.homework_view, "homework", "Ödevler", "x-office-document-symbolic")
        self.stack.add_titled_with_icon(self.exams_view, "exams", "Sınavlar", "emblem-documents-symbolic")
        self.stack.add_titled_with_icon(self.food_view, "food", "Yemek Listesi", "open-menu-symbolic")
        self.stack.add_titled_with_icon(self.announcements_view, "announcements", "Duyuru ve Etkinlik", "notifications-symbolic")
        self.stack.add_titled_with_icon(self.teachers_view, "teachers", "Öğretmenler", "avatar-default-symbolic")
        self.stack.add_titled_with_icon(self.messages_view, "messages", "Gelen Kutusu", "mail-inbox-symbolic")
        self.stack.add_titled_with_icon(self.profile_view, "profile", "Profil", "contact-new-symbolic")

        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        
        header_bar = Adw.HeaderBar()
        self.window_title = Adw.WindowTitle(title="LimeOBS", subtitle="Öğrenci Bilgi Sistemi")
        header_bar.set_title_widget(self.window_title)

        # ⚡ Hızlı Komut Paleti Butonu (Ctrl + K)
        palette_btn = Gtk.Button(icon_name="system-search-symbolic")
        palette_btn.set_tooltip_text("Hızlı Komut Paleti (Ctrl + K)")
        palette_btn.connect("clicked", lambda _: self.open_command_palette())
        header_bar.pack_start(palette_btn)

        # 🎨 Tema Değiştirme Butonu (Liquid Glass / Beyaz / Koyu)
        theme_btn = Gtk.Button(icon_name="preferences-desktop-appearance-symbolic")
        theme_btn.set_tooltip_text("Tema Değiştir (Liquid Glass / Beyaz / Koyu)")
        
        def on_theme_toggle(_):
            cur_theme = get_saved_theme()
            if cur_theme == "liquid":
                next_theme = "light"
            elif cur_theme == "light":
                next_theme = "dark"
            else:
                next_theme = "liquid"
            self.get_application().apply_theme(next_theme)
        
        theme_btn.connect("clicked", on_theme_toggle)
        header_bar.pack_end(theme_btn)

        # 🔔 Bildirimler Butonu (Tıklayınca doğrudan Gelen Kutusu'na gider)
        notify_btn = Gtk.Button(icon_name="mail-unread-symbolic")
        notify_btn.set_tooltip_text("Bildirimler & Gelen Kutusu")
        notify_btn.connect("clicked", lambda _: self.goto_messages())
        header_bar.pack_end(notify_btn)

        refresh_btn = Gtk.Button(icon_name="view-refresh-symbolic")
        refresh_btn.set_tooltip_text("Tüm Verileri Yenile")
        refresh_btn.connect("clicked", lambda _: self.on_refresh_all(None))
        header_bar.pack_end(refresh_btn)

        content_box.append(header_bar)
        content_box.append(self.stack)

        self.content_page = Adw.NavigationPage.new(content_box, "İçerik")
        self.split_view.set_content(self.content_page)

        return self.split_view

    def navigate_to_tab(self, tab_tag):
        if tab_tag == "change_password":
            self.stack.set_visible_child_name("profile")
            for row, tag in self.rows_map.items():
                if tag == "profile":
                    self.nav_list.select_row(row)
                    break
            if hasattr(self, "profile_view") and hasattr(self.profile_view, "show_change_password_dialog"):
                GLib.idle_add(self.profile_view.show_change_password_dialog)
            return

        self.stack.set_visible_child_name(tab_tag)
        for row, tag in self.rows_map.items():
            if tag == tab_tag:
                self.nav_list.select_row(row)
                break

    def goto_messages(self):
        self.navigate_to_tab("messages")

    def build_sidebar(self):
        sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        sidebar_box.set_margin_top(14)
        sidebar_box.set_margin_bottom(14)
        sidebar_box.set_margin_start(12)
        sidebar_box.set_margin_end(12)

        # 0. LimeOBS Logo ve Başlık Başlangıcı
        brand_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        brand_box.set_margin_top(8)
        brand_box.set_margin_bottom(10)
        brand_box.set_margin_start(6)

        logo_file = Path(__file__).parent / "app_icon.png"
        if logo_file.exists():
            brand_img = Gtk.Image.new_from_file(str(logo_file))
            brand_img.set_pixel_size(28)
            brand_box.append(brand_img)

        brand_label = Gtk.Label()
        brand_label.set_markup("<span size='large' weight='bold'>LimeOBS</span>")
        brand_box.append(brand_label)
        sidebar_box.append(brand_box)

        # 1. Profil Kartı (Tıklanabilir -> ProfileView'e gider)
        profile_card = Adw.PreferencesGroup()
        self.user_row = Adw.ActionRow()
        self.user_row.set_title("Giriş Yapıldı")
        self.user_row.set_subtitle("Profili Görüntüle")
        
        self.sidebar_avatar = Adw.Avatar()
        self.sidebar_avatar.set_size(36)
        self.sidebar_avatar.set_show_initials(True)
        self.sidebar_avatar.set_text("K")
        self.user_row.add_prefix(self.sidebar_avatar)

        self.user_row.set_activatable(True)
        self.user_row.connect("activated", lambda _: self.stack.set_visible_child_name("profile"))
        profile_card.add(self.user_row)
        sidebar_box.append(profile_card)

        # 2. Gezinme Menüsü
        nav_group = Adw.PreferencesGroup()
        nav_group.set_title("Gezinme")

        self.nav_list = Gtk.ListBox()
        self.nav_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.nav_list.add_css_class("navigation-sidebar")

        menu_items = [
            ("Anasayfa", "user-home-symbolic", "home"),
            ("Ders Programı", "appointment-soon-symbolic", "schedule"),
            ("Devamsızlık Takip", "user-available-symbolic", "attendance"),
            ("Ödevlerim", "x-office-document-symbolic", "homework"),
            ("Sınavlar", "emblem-documents-symbolic", "exams"),
            ("Yemek Listesi", "open-menu-symbolic", "food"),
            ("Duyuru ve Etkinlik", "notifications-symbolic", "announcements"),
            ("Öğretmenlerim", "avatar-default-symbolic", "teachers"),
            ("Gelen Kutusu", "mail-inbox-symbolic", "messages"),
            ("Kullanıcı Profili", "contact-new-symbolic", "profile"),
        ]

        self.rows_map = {}
        for title, icon, tag in menu_items:
            row = Adw.ActionRow()
            row.set_title(title)
            img = Gtk.Image.new_from_icon_name(icon)
            row.add_prefix(img)
            row.set_activatable(True)
            self.nav_list.append(row)
            self.rows_map[row] = tag

        self.nav_list.connect("row-activated", self.on_menu_activated)
        nav_group.add(self.nav_list)
        sidebar_box.append(nav_group)

        first_row = self.nav_list.get_row_at_index(0)
        if first_row:
            self.nav_list.select_row(first_row)

        # Boşluk genişletici
        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        sidebar_box.append(spacer)

        # 3. Sol Alt Bilgi Kartı: Bağlı Okul & Eğitim Dönemi
        school_info_group = Adw.PreferencesGroup()
        self.school_info_row = Adw.ActionRow()
        self.school_info_row.set_title("Bağlı Okul: Yükleniyor...")
        self.school_info_row.set_subtitle("Eğitim Dönemi: -")
        school_icon = Gtk.Image.new_from_icon_name("open-menu-symbolic")
        self.school_info_row.add_prefix(school_icon)
        school_info_group.add(self.school_info_row)
        sidebar_box.append(school_info_group)

        # Çıkış Yap Butonu
        logout_btn = Gtk.Button(label="Çıkış Yap")
        logout_btn.add_css_class("destructive-action")
        logout_btn.set_icon_name("system-log-out-symbolic")
        logout_btn.connect("clicked", lambda _: self.on_logout_clicked())
        sidebar_box.append(logout_btn)

        return sidebar_box

    def on_menu_activated(self, listbox, row):
        tag = self.rows_map.get(row)
        if tag:
            self.stack.set_visible_child_name(tag)

    def on_login_successful(self):
        self.main_stack.set_visible_child_name("dashboard")
        self.on_refresh_all(None)

    def on_logout_clicked(self):
        clear_cache()
        cookie_file = ROOT_DIR / "akbim_session.pkl"
        if cookie_file.exists():
            cookie_file.unlink()
        akbim_api.session.cookies.clear()
        self.main_stack.set_visible_child_name("login")

    def on_refresh_all(self, button):
        def worker():
            try:
                profile = get_adaptive_profile_data()
                school_meta = get_school_metadata()
                role = profile.get("role", "Öğrenci")
                is_parent = (role == "Veli")
                
                name = profile.get("parent_name") if is_parent else profile.get("student_name")
                name = name or "Kullanıcı"
                sinif = profile.get("student_class", "")
                student_no = profile.get("student_no", "")

                # Sol üst profil alt yazısı (Öğrenci Numarası ekli)
                if is_parent:
                    subtitle_parts = ["Veli Hesabı"]
                    if student_no:
                        subtitle_parts.append(f"Öğr No: {student_no}")
                    subtitle = " • ".join(subtitle_parts)
                else:
                    subtitle_parts = []
                    if sinif:
                        subtitle_parts.append(f"Sınıf: {sinif}")
                    if student_no:
                        subtitle_parts.append(f"No: {student_no}")
                    subtitle = " • ".join(subtitle_parts) if subtitle_parts else "Öğrenci Hesabı"

                photo_bytes = profile.get("photo_bytes")
                school_name = school_meta.get("school_name", "Akbim OBS")
                academic_term = school_meta.get("academic_term", "2026-2027")

                GLib.idle_add(self.update_user_header, name, subtitle, photo_bytes, school_name, academic_term)
                GLib.idle_add(self.home_view.load_data)
                GLib.idle_add(self.schedule_view.load_data)
                GLib.idle_add(self.attendance_view.load_data)
                GLib.idle_add(self.homework_view.load_data)
                GLib.idle_add(self.exams_view.load_data)
                GLib.idle_add(self.food_view.load_data)
                GLib.idle_add(self.announcements_view.load_data)
                GLib.idle_add(self.teachers_view.load_data)
                GLib.idle_add(self.messages_view.load_data)
                GLib.idle_add(self.profile_view.load_data)
            except Exception as e:
                print(f"Yenileme hatası: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def update_user_header(self, name, subtitle, photo_bytes=None, school_name="Akbim OBS", academic_term="2026-2027"):
        self.user_row.set_title(name)
        self.user_row.set_subtitle(subtitle)
        self.sidebar_avatar.set_text(name)
        if photo_bytes:
            try:
                glib_bytes = GLib.Bytes.new(photo_bytes)
                texture = Gdk.Texture.new_from_bytes(glib_bytes)
                self.sidebar_avatar.set_custom_image(texture)
            except Exception as e:
                print(f"Sidebar avatar hatası: {e}")

        # Sol alttaki okul ve eğitim dönemi bilgisi
        self.school_info_row.set_title(f"Bağlı Okul: {school_name}")
        self.school_info_row.set_subtitle(f"Eğitim Dönemi: {academic_term}")


if __name__ == "__main__":
    app = AkbimApplication()
    app.run(sys.argv)
