import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw


LESSON_NAMES = [
    ("1", "TÜRKÇE"),
    ("2", "MATEMATİK"),
    ("3", "DİN KÜLTÜRÜ"),
    ("4", "FEN VE TEKNOLOJİ"),
    ("5", "SOSYAL BİLGİLER"),
    ("6", "İNGİLİZCE"),
]


class ExamReportWindow(Adw.Window):
    def __init__(self, parent, exam_title, report_json):
        super().__init__()
        self.set_title(f"Sınav Karnesi — {exam_title}")
        self.set_transient_for(parent)
        self.set_modal(True)
        self.set_default_size(780, 680)

        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        # HeaderBar
        header_bar = Adw.HeaderBar()
        header_bar.set_title_widget(Adw.WindowTitle(title="Sınav Karnesi & Netler", subtitle=exam_title))
        main_box.append(header_bar)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)

        clamp = Adw.Clamp()
        clamp.set_maximum_size(720)

        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        content_box.set_margin_top(20)
        content_box.set_margin_bottom(25)
        content_box.set_margin_start(16)
        content_box.set_margin_end(16)

        data = report_json.get("data", {})
        subanal = report_json.get("subanal", [])

        # 1. BÜYÜK BAŞARI VE PUAN KARTI
        score_group = Adw.PreferencesGroup()
        score_group.set_title("🏆 Sınav Puanı ve Başarı Özeti")

        puan = data.get("Puan", "-")
        toplam_net = data.get("N7", "-")
        toplam_dogru = data.get("D7", "-")
        toplam_yanlis = data.get("Y7", "-")
        sinif_derece = data.get("SD", "-")
        genel_derece = data.get("GD", "-")

        # Puan ve Net Satırı
        row_puan = Adw.ActionRow()
        row_puan.set_title(f"Sınav Puanı: {puan}")
        row_puan.set_subtitle(f"Toplam Net: {toplam_net}  •  Doğru: {toplam_dogru}  •  Yanlış: {toplam_yanlis}")
        row_puan.set_icon_name("starred-symbolic")
        
        badge_puan = Gtk.Label(label=f"{puan} Puan")
        badge_puan.add_css_class("badge-primary")
        row_puan.add_suffix(badge_puan)
        score_group.add(row_puan)

        # Derece Satırı
        row_derece = Adw.ActionRow()
        row_derece.set_title("Sıralama ve Dereceler")
        row_derece.set_subtitle(f"Sınıf Derecesi: {sinif_derece}.  •  Genel Derece: {genel_derece}.")
        row_derece.set_icon_name("emblem-documents-symbolic")
        score_group.add(row_derece)

        content_box.append(score_group)

        # 2. DERS BAZLI KARNE (NETLER & DOĞRU/YANLIŞ)
        lessons_group = Adw.PreferencesGroup()
        lessons_group.set_title("📚 Ders Bazlı Net ve Soru Karnesi")

        for idx, lesson_name in LESSON_NAMES:
            sr = data.get(f"SR{idx}")
            d = data.get(f"D{idx}")
            y = data.get(f"Y{idx}")
            n = data.get(f"N{idx}")

            if sr is not None or n is not None:
                row = Adw.ActionRow()
                row.set_title(lesson_name)
                row.set_subtitle(f"Net: {n}  •  Doğru: {d}  •  Yanlış: {y}  •  Soru: {sr}")
                row.set_icon_name("appointment-soon-symbolic")
                
                net_badge = Gtk.Label(label=f"{n} Net")
                net_badge.add_css_class("badge-primary")
                row.add_suffix(net_badge)

                lessons_group.add(row)

        content_box.append(lessons_group)

        # 3. KONU ANALİZİ (EN ÇOK DİKKAT ÇEKEN KONULAR)
        if subanal:
            topic_group = Adw.PreferencesGroup()
            topic_group.set_title("🔍 Konu Analizi (Kazanım Başarısı)")
            topic_group.set_description("Konulara göre doğru/yanlış ve başarı oranları")

            for topic in subanal[:12]:  # İlk 12 önemli konuyu listele
                konu_ad = topic.get("konuAd", "-")
                ders = topic.get("lesson", "")
                dogru = topic.get("Dog", 0)
                yanlis = topic.get("Yan", 0)
                basari = topic.get("Bas", 0)

                t_row = Adw.ActionRow()
                t_row.set_title(f"[{ders}] {konu_ad}")
                t_row.set_subtitle(f"Doğru: {dogru}  •  Yanlış: {yanlis}  •  Başarı: %{basari}")
                
                t_badge = Gtk.Label(label=f"%{basari}")
                t_badge.add_css_class("badge-primary" if float(basari) >= 50 else "error-text")
                t_row.add_suffix(t_badge)

                topic_group.add(t_row)

            content_box.append(topic_group)

        clamp.set_child(content_box)
        scrolled.set_child(clamp)
        main_box.append(scrolled)

        self.set_content(main_box)
