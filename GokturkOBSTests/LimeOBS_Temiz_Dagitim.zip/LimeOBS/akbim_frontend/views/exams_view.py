import threading
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib

from api_bridge import get_adaptive_index_data, fetch_exam_report
from views.exam_report_dialog import ExamReportWindow


class ExamsView(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_vexpand(True)
        self.set_hexpand(True)

        clamp = Adw.Clamp()
        clamp.set_maximum_size(900)

        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.main_box.set_margin_top(20)
        self.main_box.set_margin_bottom(20)
        self.main_box.set_margin_start(16)
        self.main_box.set_margin_end(16)

        header_label = Gtk.Label()
        header_label.set_markup("<span size='large' weight='bold'>📝 Sınavlar ve Karneler</span>")
        header_label.set_halign(Gtk.Align.START)
        self.main_box.append(header_label)

        self.exams_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.main_box.append(self.exams_container)

        clamp.set_child(self.main_box)
        self.set_child(clamp)

    def load_data(self):
        def worker():
            try:
                data = get_adaptive_index_data()
                exams = data.get("data", {}).get("examList", []) or []
                GLib.idle_add(self.render_exams, exams)
            except Exception as e:
                print(f"Sınavlar yükleme hatası: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def render_exams(self, exams):
        child = self.exams_container.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            self.exams_container.remove(child)
            child = next_child

        exams_group = Adw.PreferencesGroup()
        exams_group.set_title("Planlanan ve Girilen Sınavlar")
        exams_group.set_description("Puanınızı ve netlerinizi görmek için sınava tıklayın")

        if not exams:
            row = Adw.ActionRow()
            row.set_title("Kayıtlı sınav bulunamadı.")
            exams_group.add(row)
        else:
            for s in exams:
                tur = s.get("examType", "SBS")
                ad = s.get("sinavAd", "-")
                tarih = s.get("sinavTarih", "-")
                kod = s.get("sinavKod", "-")

                row = Adw.ActionRow()
                row.set_title(f"[{tur}] {ad}")
                row.set_subtitle(f"Tarih: {tarih}  •  Sınav Kodu: {kod}  •  (Karneyi görmek için tıkla)")
                row.set_icon_name("emblem-documents-symbolic")
                row.set_activatable(True)

                # Karneyi incele butonu
                btn = Gtk.Button(label="Karne")
                btn.add_css_class("suggested-action")
                btn.connect("clicked", lambda _, eid=kod, etype=tur, title=ad: self.on_exam_clicked(eid, etype, title))
                row.add_suffix(btn)

                # Satır tıklaması
                row.connect("activated", lambda _, eid=kod, etype=tur, title=ad: self.on_exam_clicked(eid, etype, title))

                exams_group.add(row)

        self.exams_container.append(exams_group)

    def on_exam_clicked(self, exam_id, exam_type, exam_title):
        def worker():
            try:
                report = fetch_exam_report(exam_id, exam_type)
                if report and report.get("success"):
                    GLib.idle_add(self.show_report_dialog, exam_title, report)
                else:
                    GLib.idle_add(self.show_not_ready_dialog, exam_title)
            except Exception as e:
                print(f"Karne açma hatası: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def show_report_dialog(self, exam_title, report_json):
        root_window = self.get_root()
        dialog = ExamReportWindow(root_window, exam_title, report_json)
        dialog.present()

    def show_not_ready_dialog(self, exam_title):
        root_window = self.get_root()
        alert = Adw.AlertDialog.new(
            "Karne Henüz Yüklenmedi",
            f"'{exam_title}' sınavının sonuçları ve karnesi okul tarafından henüz sisteme işlenmemiş."
        )
        alert.add_response("ok", "Tamam")
        alert.present(root_window)
