import os
import tempfile
import threading
import subprocess
import io
from pathlib import Path
from pypdf import PdfReader

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib

from api_bridge import fetch_food_list_data
from views.pdf_viewer_dialog import open_pdf_viewer


def parse_food_menu(pdf_bytes):
    """
    Okulun yemek listesi PDF dosyasını gün gün, yemek yemek tertemiz bir veri yapısına döker.
    """
    if not pdf_bytes:
        return []

    try:
        reader = PdfReader(io.BytesIO(pdf_bytes))
        all_weeks = []

        for p_idx, page in enumerate(reader.pages):
            items = []
            def visitor(text, cm, tm, font_dict, font_size):
                if text.strip():
                    items.append((tm[4], tm[5], text.strip()))
            page.extract_text(visitor_text=visitor)

            # Tarih başlıklarını bul (y koordinatı 430 ile 480 arasında)
            date_items = [
                it for it in items 
                if 430 <= it[1] <= 480 and any(d in it[2] for d in ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"])
            ]
            date_items.sort(key=lambda it: it[0])

            if not date_items:
                continue

            cols = []
            for i, d in enumerate(date_items):
                x_start = d[0] - 25
                x_end = date_items[i+1][0] - 25 if i+1 < len(date_items) else 9999
                cols.append({
                    "date": d[2],
                    "x_start": x_start,
                    "x_end": x_end,
                    "food_items": []
                })

            # Yemek satırları (y koordinatı 100 ile 430 arasında)
            food_texts = [it for it in items if 100 <= it[1] < 430]
            for it in food_texts:
                x, y, txt = it
                for col in cols:
                    if col["x_start"] <= x < col["x_end"]:
                        col["food_items"].append((y, txt))
                        break

            days = []
            for col in cols:
                # Yukarıdan aşağıya sırala
                col["food_items"].sort(key=lambda it: -it[0])
                meals = []
                cur_meal = []
                last_y = None
                for y, txt in col["food_items"]:
                    if last_y is not None and abs(last_y - y) > 22:
                        if cur_meal:
                            m_str = " ".join(cur_meal)
                            m_str = m_str.replace("  ", " ").replace("TA VUK", "TAVUK").replace("PİLA VI", "PİLAVI").replace("T . Y", "T.Y").replace("Z . Y", "Z.Y")
                            meals.append(m_str)
                            cur_meal = []
                    cur_meal.append(txt)
                    last_y = y

                if cur_meal:
                    m_str = " ".join(cur_meal)
                    m_str = m_str.replace("  ", " ").replace("TA VUK", "TAVUK").replace("PİLA VI", "PİLAVI").replace("T . Y", "T.Y").replace("Z . Y", "Z.Y")
                    meals.append(m_str)

                days.append({
                    "date": col["date"],
                    "meals": meals
                })

            all_weeks.append({
                "week_num": p_idx + 1,
                "days": days
            })

        return all_weeks
    except Exception as e:
        print(f"Yemek listesi ayrıştırma hatası: {e}")
        return []


class FoodListView(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_vexpand(True)
        self.set_hexpand(True)

        self.pdf_bytes = None
        self.temp_pdf_path = None
        self.is_loading = False

        clamp = Adw.Clamp()
        clamp.set_maximum_size(900)

        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        self.main_box.set_margin_top(20)
        self.main_box.set_margin_bottom(30)
        self.main_box.set_margin_start(16)
        self.main_box.set_margin_end(16)

        # Üst Başlık & Butonlar
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        
        header_label = Gtk.Label()
        header_label.set_markup("<span size='large' weight='bold'>🍽️ Okul Yemek Listesi</span>")
        header_label.set_halign(Gtk.Align.START)
        header_label.set_hexpand(True)
        header_box.append(header_label)

        refresh_btn = Gtk.Button(icon_name="view-refresh-symbolic")
        refresh_btn.set_tooltip_text("Yemek Listesini Yenile")
        refresh_btn.connect("clicked", lambda _: self.load_data())
        header_box.append(refresh_btn)

        self.open_pdf_btn = Gtk.Button(label="Orijinal PDF")
        self.open_pdf_btn.set_icon_name("document-open-symbolic")
        self.open_pdf_btn.connect("clicked", self.on_open_pdf_clicked)
        self.open_pdf_btn.set_sensitive(False)
        header_box.append(self.open_pdf_btn)

        self.main_box.append(header_box)

        # Hafta Seçim Sekmesi (ViewStackSwitcher / Segmented)
        self.stack = Adw.ViewStack()
        self.switcher = Adw.ViewSwitcher()
        self.switcher.set_stack(self.stack)
        self.switcher.set_policy(Adw.ViewSwitcherPolicy.WIDE)
        self.switcher.set_halign(Gtk.Align.CENTER)
        self.switcher.set_visible(False)
        self.main_box.append(self.switcher)

        # İçerik Alanı
        self.content_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.main_box.append(self.content_container)

        clamp.set_child(self.main_box)
        self.set_child(clamp)

        self.show_loading()

    def show_loading(self):
        self.clear_container()
        self.switcher.set_visible(False)
        loading_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        loading_box.set_halign(Gtk.Align.CENTER)
        loading_box.set_valign(Gtk.Align.CENTER)
        loading_box.set_margin_top(60)
        loading_box.set_margin_bottom(60)

        spinner = Gtk.Spinner()
        spinner.set_size_request(36, 36)
        spinner.start()
        loading_box.append(spinner)

        lbl = Gtk.Label()
        lbl.set_markup("<span size='medium' weight='semibold'>Yemek listesi hazırlanıyor...</span>")
        loading_box.append(lbl)

        self.content_container.append(loading_box)

    def clear_container(self):
        child = self.content_container.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            self.content_container.remove(child)
            child = next_child

    def load_data(self):
        if self.is_loading:
            return
        self.is_loading = True
        self.show_loading()

        def worker():
            try:
                res = fetch_food_list_data()
                pdf_bytes = res.get("pdf_bytes") if res.get("success") else None
                weeks = parse_food_menu(pdf_bytes)
                GLib.idle_add(self.on_data_loaded, pdf_bytes, weeks)
            except Exception as e:
                print(f"Yemek listesi yükleme hatası: {e}")
                GLib.idle_add(self.on_data_loaded, None, [])

        threading.Thread(target=worker, daemon=True).start()

    def on_data_loaded(self, pdf_bytes, weeks):
        self.is_loading = False
        self.clear_container()
        self.pdf_bytes = pdf_bytes

        if not pdf_bytes or not weeks:
            self.open_pdf_btn.set_sensitive(False)
            self.switcher.set_visible(False)
            group = Adw.PreferencesGroup()
            group.set_title("Yemek Listesi")
            row = Adw.ActionRow()
            row.set_title("Yemek listesi bulunamadı")
            row.set_subtitle("Kurumunuz tarafından sisteme henüz yemek listesi yüklenmemiş.")
            row.set_icon_name("dialog-information-symbolic")
            group.add(row)
            self.content_container.append(group)
            return

        self.open_pdf_btn.set_sensitive(True)

        # PDF'i yerel geçici dosyaya kaydet (isteyen orijinal PDF'e de baksın)
        try:
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf", prefix="akbim_yemek_")
            tmp.write(pdf_bytes)
            tmp.close()
            self.temp_pdf_path = tmp.name
        except Exception:
            pass

        # ViewStack'i temizle
        # Eski sayfaları temizle
        while True:
            child = self.stack.get_visible_child()
            if not child:
                break
            page = self.stack.get_page(child)
            if page:
                self.stack.remove(child)
            else:
                break

        # Her hafta için tertemiz bir sayfa oluştur
        for w in weeks:
            wn = w["week_num"]
            week_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)

            for day in w["days"]:
                day_group = Adw.PreferencesGroup()
                day_group.set_title(f"📅 {day['date']}")

                meals = day["meals"]
                if not meals or all("TATİL" in m.upper() for m in meals):
                    row = Adw.ActionRow()
                    row.set_title("🏖️ Resmi / Okul Tatili")
                    row.set_subtitle("Bugün yemek hizmeti bulunmuyor.")
                    row.set_icon_name("weather-clear-symbolic")
                    day_group.add(row)
                else:
                    for idx, meal in enumerate(meals):
                        row = Adw.ActionRow()
                        row.set_title(meal)
                        
                        # Yemek kategorisi simgeleri
                        m_upper = meal.upper()
                        if "ÇORBA" in m_upper:
                            row.set_icon_name("view-list-bullet-symbolic")
                            row.set_subtitle("Başlangıç / Çorba")
                        elif any(k in m_upper for k in ["KEBAP", "KÖFTE", "TAVUK", "ET", "PİZZA", "NOHUT", "KARNIYARIK", "FASÜLYE", "DÖNER"]):
                            row.set_icon_name("emblem-favorite-symbolic")
                            row.set_subtitle("Ana Yemek")
                        elif any(k in m_upper for k in ["PİLAV", "MAKARNA", "BÖREK", "SPAGETTİ", "ERİŞTE"]):
                            row.set_icon_name("pan-end-symbolic")
                            row.set_subtitle("Garnitür / Yardımcı Yemek")
                        elif any(k in m_upper for k in ["TATLI", "MEYVE", "İÇECEK", "SU", "SALATBAR"]):
                            row.set_icon_name("starred-symbolic")
                            row.set_subtitle("Tatlı / İçecek / Salata")
                        else:
                            row.set_icon_name("tag-symbolic")

                        day_group.add(row)

                week_box.append(day_group)

            self.stack.add_titled_with_icon(week_box, f"week_{wn}", f"{wn}. Hafta", "view-list-bullet-symbolic")

        self.switcher.set_visible(True)
        self.content_container.append(self.stack)

    def on_open_pdf_clicked(self, button):
        if self.temp_pdf_path and os.path.exists(self.temp_pdf_path):
            try:
                open_pdf_viewer(self.get_root(), self.temp_pdf_path, title="Yemek Menüsü PDF")
            except Exception as e:
                print(f"Dahili PDF açma hatası: {e}")
                from api_bridge import open_file_external
                open_file_external(self.temp_pdf_path)

