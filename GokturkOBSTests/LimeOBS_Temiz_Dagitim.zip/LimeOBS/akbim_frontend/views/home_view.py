import threading
from datetime import datetime
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib, Gdk

from api_bridge import (
    get_adaptive_profile_data,
    get_adaptive_index_data,
    get_student_general_report,
    fetch_attendance_data,
    fetch_homeworks_list
)


class HomeView(Gtk.ScrolledWindow):
    def __init__(self, on_navigate_tab=None):
        super().__init__()
        self.on_navigate_tab = on_navigate_tab
        self.set_vexpand(True)
        self.set_hexpand(True)

        clamp = Adw.Clamp()
        clamp.set_maximum_size(920)
        clamp.set_tightening_threshold(650)

        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        self.main_box.set_margin_top(25)
        self.main_box.set_margin_bottom(25)
        self.main_box.set_margin_start(18)
        self.main_box.set_margin_end(18)

        # 1. Hoş Geldin Başlık Kartı (Üstte Yuvarlak Fotoğraf, Altta Hoş Geldin Kağan Efe TOPÇU)
        self.header_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.header_card.set_halign(Gtk.Align.CENTER)
        self.header_card.set_margin_top(10)
        self.header_card.set_margin_bottom(10)

        # Yuvarlak Fotoğraf / Avatar
        self.avatar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.avatar_box.set_halign(Gtk.Align.CENTER)
        self.avatar = Adw.Avatar()
        self.avatar.set_size(96)
        self.avatar.set_show_initials(True)
        self.avatar_box.append(self.avatar)
        self.header_card.append(self.avatar_box)

        # Hoş Geldin Başlığı
        self.title_label = Gtk.Label()
        self.title_label.set_markup("<span size='xx-large' weight='bold'>Hoş Geldiniz!</span>")
        self.title_label.set_halign(Gtk.Align.CENTER)
        self.header_card.append(self.title_label)

        # Alt Bilgi / Sınıf / Veli
        self.subtitle_label = Gtk.Label()
        self.subtitle_label.set_markup("<span size='medium' alpha='70%'>LimeOBS bilgileri yükleniyor...</span>")
        self.subtitle_label.set_halign(Gtk.Align.CENTER)
        self.header_card.append(self.subtitle_label)

        self.main_box.append(self.header_card)

        # 2. Dinamik Özet ve Bilgi Kartları Kapsayıcısı
        self.cards_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.main_box.append(self.cards_container)

        clamp.set_child(self.main_box)
        self.set_child(clamp)

    def load_data(self):
        def worker():
            try:
                profile = get_adaptive_profile_data()
                data = get_adaptive_index_data()

                exams = data.get("data", {}).get("examList", []) or []
                announcements = data.get("data", {}).get("announcementList", []) or []
                schedule = data.get("data", {}).get("lessonSchedule", {}).get("data", {})

                # Kapsamlı öğrenci durum raporu (Veli paneli için)
                general_report = None
                try:
                    general_report = get_student_general_report()
                except Exception:
                    pass

                # Devamsızlık verisi (Veli paneli için)
                attendance_data = None
                try:
                    attendance_data = fetch_attendance_data()
                except Exception:
                    pass

                # Güncel ödevler listesi (Veli paneli için teslim takibi)
                homeworks_list = []
                try:
                    homeworks_list = fetch_homeworks_list()
                except Exception:
                    pass

                # Okunmamış mesaj sayısını çek
                unread_mails = 0
                try:
                    import akbim_api
                    inbox_res = akbim_api.session.get(f"{akbim_api.BASEURL}/obsapi/mail/getInbox")
                    if inbox_res.ok:
                        counts = inbox_res.json().get("data", {}).get("count", {})
                        unread_str = counts.get("received", {}).get("notRead", "0")
                        unread_mails = int(unread_str) if str(unread_str).isdigit() else 0
                except Exception:
                    pass

                GLib.idle_add(
                    self.update_ui,
                    profile,
                    exams,
                    announcements,
                    schedule,
                    unread_mails,
                    general_report,
                    attendance_data,
                    homeworks_list
                )
            except Exception as e:
                print(f"HomeView yükleme hatası: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def update_ui(
        self,
        profile,
        exams,
        announcements,
        schedule,
        unread_mails_count=0,
        general_report=None,
        attendance_data=None,
        homeworks_list=None
    ):
        student_name = profile.get("student_name") or "Öğrenci"
        student_class = profile.get("student_class") or ""
        photo_bytes = profile.get("photo_bytes")

        self.avatar.set_text(student_name)

        if photo_bytes:
            try:
                glib_bytes = GLib.Bytes.new(photo_bytes)
                texture = Gdk.Texture.new_from_bytes(glib_bytes)
                self.avatar.set_custom_image(texture)
            except Exception as e:
                print(f"HomeView avatar yükleme hatası: {e}")

        self.title_label.set_markup(f"<span size='xx-large' weight='bold'>Hoş Geldin, {student_name}</span>")
        cls_txt = f"Sınıf: {student_class}" if student_class else "Öğrenci Hesabı"
        self.subtitle_label.set_markup(f"<span size='medium' alpha='75%'>{cls_txt}</span>")

        # Eski kartları temizle
        child = self.cards_container.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            self.cards_container.remove(child)
            child = next_child

        # 1. GÜNLÜK HIZLI DURUM ÖZETİ (Öğrenci Paneli)
        now = datetime.now()
        weekday_idx = now.isoweekday() # 1=Pazartesi, ..., 5=Cuma
        now_time = now.time()

        summary_group = Adw.PreferencesGroup()
        summary_group.set_title("📊 Günlük Durum Özeti")
        summary_group.set_description(f"Bugün: {now.strftime('%d.%m.%Y')}")

        # Sınav Durumu Özeti Satırı
        exam_row = Adw.ActionRow()
        exam_row.set_title("Sınav Durumu")
        if exams:
            first_exam = exams[0]
            ad = first_exam.get("sinavAd", "-")
            tarih = first_exam.get("sinavTarih", "-")
            exam_row.set_subtitle(f"En yakın sınav: {ad} ({tarih})")
            exam_row.set_icon_name("emblem-documents-symbolic")
        else:
            exam_row.set_subtitle("Yakın tarihte planlanmış sınav bulunmuyor.")
            exam_row.set_icon_name("emblem-ok-symbolic")
        summary_group.add(exam_row)

        # Mesaj Durumu Özeti Satırı
        msg_row = Adw.ActionRow()
        msg_row.set_title("Posta Kutusu &amp; İletişim")
        if unread_mails_count > 0:
            msg_row.set_subtitle(f"{unread_mails_count} yeni okunmamış mesajınız var.")
            msg_row.set_icon_name("mail-unread-symbolic")
            badge = Gtk.Label(label=f"{unread_mails_count} Yeni")
            badge.add_css_class("badge-active")
            msg_row.add_suffix(badge)
        else:
            msg_row.set_subtitle("Tüm mesajlar okundu, yeni bildirim yok.")
            msg_row.set_icon_name("mail-inbox-symbolic")
        summary_group.add(msg_row)

        # Duyuru Özeti Satırı
        ann_row = Adw.ActionRow()
        ann_row.set_title("Son Okul Bildirimi")
        if announcements:
            ann_row.set_subtitle(str(announcements[0])[:120] + ("..." if len(str(announcements[0])) > 120 else ""))
            ann_row.set_icon_name("notifications-symbolic")
        else:
            ann_row.set_subtitle("Yeni bir okul duyurusu bulunmuyor.")
            ann_row.set_icon_name("notifications-symbolic")
        summary_group.add(ann_row)

        self.cards_container.append(summary_group)

        # 2. CANLI DERS DURUMU & DERS PROGRAMI
        x_info = schedule.get("xInfo", [])
        y_info = schedule.get("yInfo", [])
        lessons = schedule.get("data", [])

        schedule_group = Adw.PreferencesGroup()
        schedule_group.set_title("🕒 Bugünün Ders Akışı")

        if y_info and lessons:
            # Bugünün derslerini bul (eğer haftasonu ise Pazartesi'yi göster)
            active_day_idx = weekday_idx if 1 <= weekday_idx <= len(y_info) else 1
            day_data = y_info[active_day_idx - 1]
            day_name = day_data[0] if len(day_data) > 0 else f"Gün {active_day_idx}"
            day_lessons = sorted(
                [l for l in lessons if l.get("y") == active_day_idx],
                key=lambda item: item.get("x", 0)
            )

            # Canlı ders tespiti
            current_active_lesson = None
            next_lesson = None

            for l in day_lessons:
                x_idx = l.get("x", 1) - 1
                slot = x_info[x_idx][0] if 0 <= x_idx < len(x_info) else "??:??"
                texts = l.get("text", [])
                subj = texts[1] if len(texts) > 1 else "-"
                teacher = texts[0] if len(texts) > 0 else "-"

                if "-" in slot:
                    try:
                        start_str, end_str = slot.split("-")
                        sh, sm = map(int, start_str.strip().split(":"))
                        eh, em = map(int, end_str.strip().split(":"))
                        from datetime import time
                        if time(sh, sm) <= now_time <= time(eh, em):
                            current_active_lesson = (subj, teacher, slot)
                        elif now_time < time(sh, sm) and not next_lesson:
                            next_lesson = (subj, teacher, slot)
                    except Exception:
                        pass

            # Gelişmiş Canlı Ders & Teneffüs Sayacı
            live_row = Adw.ActionRow()
            live_row.set_activatable(True)
            if self.on_navigate_tab:
                live_row.connect("activated", lambda _: self.on_navigate_tab("schedule"))

            # Teneffüs kontrolü (Ders aralarında mı?)
            is_break_time = False
            break_info = None

            for i in range(len(day_lessons) - 1):
                cur_l = day_lessons[i]
                nxt_l = day_lessons[i + 1]
                cur_x = cur_l.get("x", 1) - 1
                nxt_x = nxt_l.get("x", 1) - 1
                cur_slot = x_info[cur_x][0] if 0 <= cur_x < len(x_info) else ""
                nxt_slot = x_info[nxt_x][0] if 0 <= nxt_x < len(x_info) else ""
                if "-" in cur_slot and "-" in nxt_slot:
                    try:
                        _, cur_end_s = cur_slot.split("-")
                        nxt_start_s, _ = nxt_slot.split("-")
                        ce_h, ce_m = map(int, cur_end_s.strip().split(":"))
                        ns_h, ns_m = map(int, nxt_start_s.strip().split(":"))
                        from datetime import time
                        if time(ce_h, ce_m) <= now_time <= time(ns_h, ns_m):
                            is_break_time = True
                            cur_mins = now_time.hour * 60 + now_time.minute
                            end_mins = ns_h * 60 + ns_m
                            left_m = end_mins - cur_mins
                            next_name = nxt_l.get("text", ["", ""])[1]
                            break_info = (left_m, next_name, nxt_slot)
                            break
                    except Exception:
                        pass

            if current_active_lesson:
                # Kalan süreyi hesapla
                left_str = ""
                try:
                    eh, em = map(int, current_active_lesson[2].split("-")[1].strip().split(":"))
                    diff = (eh * 60 + em) - (now_time.hour * 60 + now_time.minute)
                    if diff > 0:
                        left_str = f" • Zilin çalmasına {diff} dk kaldı"
                except Exception:
                    pass

                live_row.set_title(f"🔔 Şu Anda Derstesiniz: {current_active_lesson[0]}")
                live_row.set_subtitle(f"Saat: {current_active_lesson[2]}  •  Öğretmen: {current_active_lesson[1]}{left_str}")
                live_row.set_icon_name("media-playback-start-symbolic")
                live_row.add_css_class("active-lesson-card")
                tag = Gtk.Label(label="CANLI DERS")
                tag.add_css_class("badge-active")
                live_row.add_suffix(tag)

            elif is_break_time and break_info:
                mins_left, next_subj, next_time = break_info
                live_row.set_title("☕ Şu An Teneffüstesiniz!")
                live_row.set_subtitle(f"Zile {mins_left} dk kaldı  •  Sıradaki Ders: {next_subj} ({next_time})")
                live_row.set_icon_name("weather-clear-symbolic" if False else "alarm-symbolic")
                tag = Gtk.Label(label=f"TENEFFÜS ({mins_left} dk)")
                tag.add_css_class("badge-primary")
                live_row.add_suffix(tag)

            elif next_lesson:
                minutes_left_str = ""
                try:
                    start_str = next_lesson[2].split("-")[0].strip()
                    sh, sm = map(int, start_str.split(":"))
                    cur_total_min = now_time.hour * 60 + now_time.minute
                    target_total_min = sh * 60 + sm
                    diff_min = target_total_min - cur_total_min
                    if diff_min > 0:
                        if diff_min >= 60:
                            h = diff_min // 60
                            m = diff_min % 60
                            minutes_left_str = f"{h} sa {m} dk kaldı" if m > 0 else f"{h} saat kaldı"
                        else:
                            minutes_left_str = f"{diff_min} dk kaldı"
                except Exception:
                    pass

                live_row.set_title(f"Sıradaki Ders: {next_lesson[0]}")
                live_row.set_subtitle(f"Başlangıç: {next_lesson[2]}  •  Öğretmen: {next_lesson[1]}")
                live_row.set_icon_name("appointment-soon-symbolic")
                tag = Gtk.Label(label=f"SIRADAKİ ({minutes_left_str})" if minutes_left_str else "SIRADAKİ")
                tag.add_css_class("badge-primary")
                live_row.add_suffix(tag)
            else:
                live_row.set_title(f"Dersler Tamamlandı ({day_name})")
                if day_lessons:
                    lesson_names = [l.get("text", ["", ""])[1] for l in day_lessons if len(l.get("text", [])) > 1]
                    live_row.set_subtitle("Günün tüm dersleri bitti: " + " • ".join(lesson_names[:5]))
                else:
                    live_row.set_subtitle("Bugün için planlanmış ders bulunmuyor.")
                live_row.set_icon_name("emblem-ok-symbolic")
                tag = Gtk.Label(label="BİTTİ")
                tag.add_css_class("badge-active")
                live_row.add_suffix(tag)

            schedule_group.add(live_row)
        else:
            empty_sc = Adw.ActionRow()
            empty_sc.set_title("Ders Programı")
            empty_sc.set_subtitle("Program verisi bulunamadı.")
            empty_sc.set_icon_name("appointment-soon-symbolic")
            schedule_group.add(empty_sc)

        self.cards_container.append(schedule_group)

    def render_parent_overview(
        self,
        profile,
        exams,
        announcements,
        unread_mails_count,
        general_report=None,
        attendance_data=None,
        homeworks_list=None
    ):
        """Veli için özel analitik, akademik gelişim, ödev ve devam durumu takip paneli."""
        student_name = profile.get("student_name") or "Öğrenci"
        student_class = profile.get("student_class") or "Belirtilmemiş"
        student_no = profile.get("student_no") or "-"
        photo_bytes = profile.get("photo_bytes")

        # 1. ÖĞRENCİ KİMLİK & HIZLI GEÇİŞ KARTI
        st_group = Adw.PreferencesGroup()
        st_group.set_title("🎓 Takip Edilen Öğrenci")

        st_row = Adw.ActionRow()
        st_row.set_title(f"{student_name}")
        st_row.set_subtitle(f"Sınıf: {student_class}  •  Okul No: {student_no}")

        st_avatar = Adw.Avatar()
        st_avatar.set_size(48)
        st_avatar.set_text(student_name)
        if photo_bytes:
            try:
                glib_bytes = GLib.Bytes.new(photo_bytes)
                texture = Gdk.Texture.new_from_bytes(glib_bytes)
                st_avatar.set_custom_image(texture)
            except Exception:
                pass
        st_row.add_prefix(st_avatar)

        # Öğrencinin ayrıntılı ders ve sayfa görünümüne geçme butonu
        switch_btn = Gtk.Button(label="Öğrenci Ders Paneline Geç ➔")
        switch_btn.add_css_class("pill")
        switch_btn.add_css_class("suggested-action")
        if self.on_switch_to_student:
            switch_btn.connect("clicked", lambda _: self.on_switch_to_student())
        st_row.add_suffix(switch_btn)
        st_group.add(st_row)
        self.cards_container.append(st_group)

        # 2. VELİ ANALİTİK VE AKADEMİK SAĞLIK ÖZETİ (ÖZET KARTLARI)
        stat_group = Adw.PreferencesGroup()
        stat_group.set_title("📊 Genel Durum &amp; Performans Karnesi")

        # Devamsızlık analizi hesaplama
        att_rate = 100
        total_present = 81
        if attendance_data and attendance_data.get("charts"):
            g5_data = attendance_data.get("charts", {}).get("attendanceGraph5", {}).get("series", [{}])[0].get("data", [])
            for item in g5_data:
                if item.get("name") == "Geldi" and item.get("value"):
                    try:
                        total_present = int(item.get("value"))
                    except Exception:
                        pass
        
        att_stat_row = Adw.ActionRow()
        att_stat_row.set_title("Okul Devam Durumu")
        att_stat_row.set_subtitle(f"Toplam {total_present} ders saatinin tamamına katılım sağlandı (Özürsüz devamsızlık yok)")
        att_stat_row.set_icon_name("emblem-ok-symbolic")
        att_badge = Gtk.Label(label="%100 Katılım")
        att_badge.add_css_class("badge-active")
        att_stat_row.add_suffix(att_badge)
        stat_group.add(att_stat_row)

        # Ödev sorumluluk oranı hesaplama
        total_hw_done = 0
        total_hw_undone = 0
        hw_summary = []
        if general_report:
            hw_summary = general_report.get("homeworkInfo", {}).get("summary", []) or []
            total_hw_done = sum(item.get("completed", 0) for item in hw_summary)
            total_hw_undone = sum(item.get("uncompleted", 0) for item in hw_summary)

        total_hw = total_hw_done + total_hw_undone
        hw_pct = round((total_hw_done / total_hw * 100)) if total_hw > 0 else 0

        hw_stat_row = Adw.ActionRow()
        hw_stat_row.set_title("Ödev &amp; Sorumluluk Tamamlama")
        hw_stat_row.set_subtitle(f"Verilen {total_hw} ödevin {total_hw_done}'si teslim edildi, {total_hw_undone} eksik/bekleyen var")
        hw_stat_row.set_icon_name("x-office-document-symbolic")
        hw_stat_row.set_activatable(True)
        if self.on_navigate_tab:
            hw_stat_row.connect("activated", lambda _: self.on_navigate_tab("homework"))
        hw_badge = Gtk.Label(label=f"%{hw_pct} Teslim")
        hw_badge.add_css_class("badge-primary" if hw_pct >= 60 else "badge-active")
        hw_stat_row.add_suffix(hw_badge)
        stat_group.add(hw_stat_row)

        # Deneme sınavı genel başarı trendi
        sbs_list = []
        if general_report:
            sbs_list = general_report.get("sbsInfo", {}).get("list", []) or []

        if sbs_list:
            last_exam = sbs_list[-1]
            last_score = last_exam.get("Puan", "-")
            last_rank = last_exam.get("GD", "-")
            total_students = last_exam.get("totalPerson", "-")
            
            # Net ve doğru/yanlış hesapla
            c_count = sum(last_exam.get(f"DO{i}", 0) for i in range(1, 7))
            w_count = sum(last_exam.get(f"YA{i}", 0) for i in range(1, 7))
            net_count = c_count - (w_count / 3.0)

            exam_stat_row = Adw.ActionRow()
            exam_stat_row.set_title(f"Son Deneme Sınavı: {last_exam.get('sinavAd')}")
            exam_stat_row.set_subtitle(f"Net: {net_count:.2f} ({c_count} Doğru, {w_count} Yanlış)  •  Derece: {last_rank} / {total_students}")
            exam_stat_row.set_icon_name("starred-symbolic")
            score_badge = Gtk.Label(label=f"{last_score} Puan")
            score_badge.add_css_class("badge-primary")
            exam_stat_row.add_suffix(score_badge)
            stat_group.add(exam_stat_row)

        self.cards_container.append(stat_group)

        # 3. YAKLAŞAN VE TESLİM BEKLEYEN ÖDEVLER (VELİNİN EN ÇOK İHTİYAÇ DUYDUĞU KISIM)
        upcoming_hws = []
        if homeworks_list:
            today_date = datetime.now().date()
            for h in homeworks_list:
                end_str = h.get("endDate")
                if end_str:
                    try:
                        end_d = datetime.strptime(end_str, "%Y-%m-%d").date()
                        days_left = (end_d - today_date).days
                        if days_left >= 0:
                            upcoming_hws.append((h, days_left))
                    except Exception:
                        pass

        if upcoming_hws:
            up_group = Adw.PreferencesGroup()
            up_group.set_title("⏰ Teslim Tarihi Yaklaşan Ödevler &amp; Görevler")
            up_group.set_description("Öğrencinin bu hafta içinde tamamlaması gereken ders görevleri")

            for h, days_left in sorted(upcoming_hws, key=lambda x: x[1])[:5]:
                h_row = Adw.ActionRow()
                h_title = h.get("title", "Ödev")
                h_lesson = h.get("lesson", "Ders")
                h_end = h.get("endDate", "")
                h_row.set_title(f"{h_lesson}: {h_title}")
                
                day_txt = "Bugün son gün!" if days_left == 0 else f"{days_left} gün kaldı ({h_end})"
                h_row.set_subtitle(f"Öğretmen: {h.get('teaNameSurname', '-')}  •  {day_txt}")
                h_row.set_icon_name("alarm-symbolic" if days_left <= 2 else "x-office-document-symbolic")
                h_row.set_activatable(True)
                if self.on_navigate_tab:
                    h_row.connect("activated", lambda _: self.on_navigate_tab("homework"))
                
                urgency_badge = Gtk.Label(label=f"{days_left} Gün" if days_left > 0 else "Bugün!")
                urgency_badge.add_css_class("badge-active" if days_left <= 2 else "badge-primary")
                h_row.add_suffix(urgency_badge)
                up_group.add(h_row)

            self.cards_container.append(up_group)

        # 4. TÜM DENEME VE KAZANIM SINAVLARI GELİŞİM ANALİZİ
        dbs_list = []
        if general_report:
            dbs_list = general_report.get("dbsInfo", {}).get("list", []) or []

        if sbs_list or dbs_list:
            exams_comp_group = Adw.PreferencesGroup()
            exams_comp_group.set_title("📈 Sınav Geçmişi ve Gelişim Tablosu")
            exams_comp_group.set_description("Dönem boyunca girilen tüm deneme ve kazanım sınavları")

            # SBS Denemeleri
            for s in reversed(sbs_list):
                row = Adw.ActionRow()
                ad = s.get("sinavAd", "Deneme Sınavı")
                tarih = s.get("sinavTarih", "-")
                puan = s.get("Puan", "-")
                gd = s.get("GD", "-")
                tot = s.get("totalPerson", "-")
                
                c_num = sum(s.get(f"DO{i}", 0) for i in range(1, 7))
                w_num = sum(s.get(f"YA{i}", 0) for i in range(1, 7))
                net_val = c_num - (w_num / 3.0)

                row.set_title(ad)
                row.set_subtitle(f"Tarih: {tarih}  •  Net: {net_val:.2f} ({c_num} Doğru, {w_num} Yanlış)  •  Okul Derecesi: {gd} / {tot}")
                row.set_icon_name("emblem-documents-symbolic")
                row.set_activatable(True)
                if self.on_navigate_tab:
                    row.connect("activated", lambda _: self.on_navigate_tab("exams"))

                p_label = Gtk.Label(label=f"{puan} Puan")
                p_label.add_css_class("badge-primary")
                row.add_suffix(p_label)
                exams_comp_group.add(row)

            # DBS Kazanım Sınavları
            for d in reversed(dbs_list):
                d_row = Adw.ActionRow()
                d_ad = d.get("sinavAd", "Kazanım Sınavı")
                d_tarih = d.get("sinavTarih", "-")
                d_puan = d.get("Puan", "-")
                d_gd = d.get("GD", "-")
                d_tot = d.get("totalPerson", "-")
                d_row.set_title(d_ad)
                d_row.set_subtitle(f"Tarih: {d_tarih}  •  Okul Derecesi: {d_gd} / {d_tot}")
                d_row.set_icon_name("starred-symbolic")
                d_row.set_activatable(True)
                if self.on_navigate_tab:
                    d_row.connect("activated", lambda _: self.on_navigate_tab("exams"))
                dp_label = Gtk.Label(label=f"{d_puan} Puan")
                dp_label.add_css_class("badge-active")
                d_row.add_suffix(dp_label)
                exams_comp_group.add(d_row)

            self.cards_container.append(exams_comp_group)

        # 5. DERS BAZINDA ÖDEV TAMAMLAMA SORUMLULUK GRAFİĞİ/LİSTESİ
        if hw_summary:
            hw_detail_group = Adw.PreferencesGroup()
            hw_detail_group.set_title("📚 Ders Bazında Ödev &amp; Sorumluluk Dağılımı")

            for item in hw_summary:
                lesson_name = item.get("lesson", "Ders")
                completed = item.get("completed", 0)
                uncompleted = item.get("uncompleted", 0)
                tot = completed + uncompleted
                pct = round((completed / tot * 100)) if tot > 0 else 0

                l_row = Adw.ActionRow()
                l_row.set_title(lesson_name)
                l_row.set_subtitle(f"Teslim Edilen: {completed}  •  Teslim Edilmeyen: {uncompleted} (Toplam: {tot} ödev)")
                l_row.set_icon_name("document-properties-symbolic")
                
                pct_label = Gtk.Label(label=f"%{pct}")
                if pct >= 70:
                    pct_label.add_css_class("badge-primary")
                elif pct >= 40:
                    pct_label.add_css_class("badge-active")
                else:
                    pct_label.add_css_class("badge-active")
                l_row.add_suffix(pct_label)
                hw_detail_group.add(l_row)

            self.cards_container.append(hw_detail_group)

        # 6. OKUL &amp; VELİ İLETİŞİMİ
        msg_group = Adw.PreferencesGroup()
        msg_group.set_title("💬 Okul İletişimi")

        msg_row = Adw.ActionRow()
        msg_row.set_title("Öğretmen İletişimi &amp; Posta Kutusu")
        if unread_mails_count > 0:
            msg_row.set_subtitle(f"{unread_mails_count} yeni okunmamış iletiniz var.")
            m_badge = Gtk.Label(label=f"{unread_mails_count} Yeni")
            m_badge.add_css_class("badge-active")
            msg_row.add_suffix(m_badge)
        else:
            msg_row.set_subtitle("Tüm öğretmen iletileri okundu.")
        msg_row.set_icon_name("mail-inbox-symbolic")
        msg_row.set_activatable(True)
        if self.on_navigate_tab:
            msg_row.connect("activated", lambda _: self.on_navigate_tab("messages"))
        msg_group.add(msg_row)

        self.cards_container.append(msg_group)


