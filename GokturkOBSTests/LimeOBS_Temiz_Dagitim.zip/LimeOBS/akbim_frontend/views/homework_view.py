import threading
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib

from api_bridge import fetch_homeworks_list, fetch_homework_detail, download_homework_attachment
from views.pdf_viewer_dialog import open_pdf_viewer
import tempfile
import subprocess
from pathlib import Path


class HomeworkView(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_vexpand(True)
        self.set_hexpand(True)

        clamp = Adw.Clamp()
        clamp.set_maximum_size(920)

        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.main_box.set_margin_top(20)
        self.main_box.set_margin_bottom(20)
        self.main_box.set_margin_start(16)
        self.main_box.set_margin_end(16)

        # Başlık ve Filtre Seçici
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header_label = Gtk.Label()
        header_label.set_markup("<span size='large' weight='bold'>📚 Ödevlerim &amp; Görevler</span>")
        header_label.set_halign(Gtk.Align.START)
        header_label.set_hexpand(True)
        header_box.append(header_label)

        self.main_box.append(header_box)

        # Ödev Listesi Kapsayıcısı
        self.container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.main_box.append(self.container)

        clamp.set_child(self.main_box)
        self.set_child(clamp)

    def load_data(self):
        def worker():
            try:
                homeworks = fetch_homeworks_list()
                GLib.idle_add(self.render_homeworks, homeworks)
            except Exception as e:
                print(f"Ödevler yükleme hatası: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def render_homeworks(self, homework_list):
        child = self.container.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            self.container.remove(child)
            child = next_child

        # 1. AKTİF / TESLİM EDİLECEK ÖDEVLER
        active_group = Adw.PreferencesGroup()
        active_group.set_title("📌 Devam Eden Ödevler")
        active_group.set_description("Teslim süresi devam eden ve bekleyen ödevler")

        # 2. TAMAMLANAN VEYA GEÇMİŞ ÖDEVLER
        completed_group = Adw.PreferencesGroup()
        completed_group.set_title("✅ Geçmiş &amp; Tamamlanan Ödevler")

        active_count = 0
        completed_count = 0

        if not homework_list:
            row = Adw.ActionRow()
            row.set_title("Henüz verilmiş bir ödev bulunmuyor.")
            row.set_icon_name("emblem-ok-symbolic")
            active_group.add(row)
            self.container.append(active_group)
            return

        for hw in homework_list:
            title = hw.get("title", "Başlıksız Ödev")
            lesson = hw.get("lesson", "Ders")
            teacher = hw.get("teaNameSurname", "").strip()
            end_date = hw.get("endDate", "")
            status_name = hw.get("statusName", "Belirtilmedi")
            is_active = hw.get("isActive", False)
            status_code = hw.get("status", 0) # 1: Tamamlandı, 3: Eksik, 0: Değerlendirilmedi

            row = Adw.ActionRow()
            row.set_title(f"[{lesson}] {title}")
            
            sub_parts = []
            if teacher:
                sub_parts.append(f"Öğretmen: {teacher}")
            if end_date:
                sub_parts.append(f"Son Teslim: {end_date}")
            sub_parts.append(f"Durum: {status_name}")
            row.set_subtitle("  •  ".join(sub_parts))

            # Durum rozeti
            badge = Gtk.Label(label=status_name)
            if status_code == 1 or "Tamamlandı" in status_name:
                badge.add_css_class("badge-active")
                row.set_icon_name("emblem-ok-symbolic")
            elif status_code == 3 or "Eksik" in status_name:
                badge.add_css_class("badge-primary")
                row.set_icon_name("dialog-warning-symbolic")
            else:
                badge.add_css_class("badge-upcoming")
                row.set_icon_name("x-office-document-symbolic")

            row.add_suffix(badge)

            # Ok ikonu
            arrow = Gtk.Image.new_from_icon_name("go-next-symbolic")
            row.add_suffix(arrow)

            row.set_activatable(True)
            row.connect("activated", lambda _, item=hw: self.open_homework_detail(item))

            if is_active:
                active_group.add(row)
                active_count += 1
            else:
                completed_group.add(row)
                completed_count += 1

        if active_count == 0:
            row = Adw.ActionRow()
            row.set_title("Şu anda aktif veya teslim süresi süren ödeviniz yok.")
            row.set_icon_name("emblem-ok-symbolic")
            active_group.add(row)

        self.container.append(active_group)
        if completed_count > 0:
            self.container.append(completed_group)

    def open_homework_detail(self, hw):
        hw_id = hw.get("id")

        dialog = Adw.Window()
        root_window = self.get_root()
        if root_window:
            dialog.set_transient_for(root_window)
            dialog.set_modal(True)

        dialog.set_title("Ödev Detayı")
        dialog.set_default_size(540, 520)
        dialog.set_resizable(True)

        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        header_bar = Adw.HeaderBar()
        win_title = Adw.WindowTitle(
            title=hw.get("title", "Ödev Detayı"),
            subtitle=f"{hw.get('lesson', '')}  •  {hw.get('teaNameSurname', '')}".strip(" •")
        )
        header_bar.set_title_widget(win_title)
        main_box.append(header_bar)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_hexpand(True)

        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        content_box.set_margin_top(18)
        content_box.set_margin_bottom(20)
        content_box.set_margin_start(20)
        content_box.set_margin_end(20)

        # Genel Bilgiler
        info_group = Adw.PreferencesGroup()
        info_group.set_title("Ödev Bilgileri")

        teacher_row = Adw.ActionRow()
        teacher_row.set_title("Ders &amp; Öğretmen")
        teacher_row.set_subtitle(f"{hw.get('lesson', '-')}  —  {hw.get('teaNameSurname', '-')}")
        teacher_row.set_icon_name("avatar-default-symbolic")
        info_group.add(teacher_row)

        date_row = Adw.ActionRow()
        date_row.set_title("Tarih Aralığı")
        date_row.set_subtitle(f"Başlangıç: {hw.get('startDate', '-')}  •  Son Teslim: {hw.get('endDate', '-')}")
        date_row.set_icon_name("appointment-soon-symbolic")
        info_group.add(date_row)

        status_row = Adw.ActionRow()
        status_row.set_title("Teslim Durumu")
        status_row.set_subtitle(f"{hw.get('statusName', '-')}")
        status_row.set_icon_name("emblem-documents-symbolic")
        info_group.add(status_row)

        content_box.append(info_group)

        # Açıklama / İçerik
        desc_group = Adw.PreferencesGroup()
        desc_group.set_title("Öğretmen Açıklaması")

        desc_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        desc_card.add_css_class("card")
        desc_card.set_margin_top(4)

        desc_label = Gtk.Label()
        desc_label.set_wrap(True)
        desc_label.set_selectable(True)
        desc_label.set_xalign(0)
        desc_label.set_margin_top(16)
        desc_label.set_margin_bottom(16)
        desc_label.set_margin_start(16)
        desc_label.set_margin_end(16)
        desc_label.set_text("Açıklama yükleniyor...")
        desc_card.append(desc_label)
        desc_group.add(desc_card)

        content_box.append(desc_group)

        # Ek Dosyalar Grubu
        attachment_group = Adw.PreferencesGroup()
        content_box.append(attachment_group)

        scroll.set_child(content_box)
        main_box.append(scroll)
        dialog.set_content(main_box)
        dialog.present()

        # Detayı arka planda çek
        def fetch_worker():
            detail = fetch_homework_detail(hw_id)
            if not detail:
                GLib.idle_add(lambda: desc_label.set_text("Açıklama belirtilmemiş."))
                return

            desc = detail.get("description") or "Öğretmen tarafından yazılı bir açıklama eklenmemiş."
            files = detail.get("attachFiles", [])
            teacher_note = detail.get("teacherComment", "")

            def update_ui():
                desc_label.set_text(desc)
                if teacher_note:
                    note_row = Adw.ActionRow()
                    note_row.set_title("Öğretmen Notu / Dönütü")
                    note_row.set_subtitle(teacher_note)
                    note_row.set_icon_name("dialog-information-symbolic")
                    info_group.add(note_row)

                if files:
                    attachment_group.set_title(f"Ödev Ek Dosyaları ({len(files)})")
                    for f in files:
                        fname = f.get("fileName", "Ek Dosya")
                        fid = f.get("fileId")
                        frow = Adw.ActionRow()
                        frow.set_title(fname)
                        frow.set_subtitle("Görüntülemek veya indirmek için tıklayın")
                        frow.set_icon_name("mail-attachment-symbolic")
                        frow.set_activatable(True)

                        dl_btn = Gtk.Button(label="Aç / İndir")
                        dl_btn.add_css_class("suggested-action")
                        
                        def make_dl_handler(file_id, file_name, button_widget):
                            def on_click(_):
                                button_widget.set_sensitive(False)
                                button_widget.set_label("İndiriliyor...")
                                def dl_worker():
                                    file_bytes, err = download_homework_attachment(hw_id, file_id)
                                    def dl_done():
                                        button_widget.set_sensitive(True)
                                        button_widget.set_label("Aç / İndir")
                                        if file_bytes:
                                            suffix = (Path(file_name).suffix or ".pdf").lower()
                                            if suffix == ".pdf":
                                                open_pdf_viewer(dialog, file_bytes, title=f"Ödev Eki: {file_name}")
                                            else:
                                                tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
                                                tmp.write(file_bytes)
                                                tmp.close()
                                                from api_bridge import open_file_external
                                                open_file_external(tmp.name)
                                        else:
                                            alert = Adw.AlertDialog.new("İndirme Hatası", err or "Dosya indirilemedi.")
                                            alert.add_response("ok", "Tamam")
                                            alert.present(dialog)
                                    GLib.idle_add(dl_done)
                                threading.Thread(target=dl_worker, daemon=True).start()
                            return on_click

                        handler = make_dl_handler(fid, fname, dl_btn)
                        dl_btn.connect("clicked", handler)
                        frow.connect("activated", handler)
                        frow.add_suffix(dl_btn)
                        attachment_group.add(frow)

            GLib.idle_add(update_ui)

        threading.Thread(target=fetch_worker, daemon=True).start()
