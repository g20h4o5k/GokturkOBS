import threading
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib

import akbim_api


class LoginView(Gtk.Box):
    def __init__(self, on_login_success):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.set_vexpand(True)
        self.set_hexpand(True)
        self.on_login_success = on_login_success

        clamp = Adw.Clamp()
        clamp.set_maximum_size(450)
        clamp.set_tightening_threshold(350)

        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        main_box.set_margin_top(40)
        main_box.set_margin_bottom(40)
        main_box.set_margin_start(20)
        main_box.set_margin_end(20)

        # 1. Başlık & Logo
        from pathlib import Path
        logo_path = Path(__file__).resolve().parent.parent / "app_icon.png"

        logo_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        logo_box.set_halign(Gtk.Align.CENTER)

        if logo_path.exists():
            logo_img = Gtk.Image.new_from_file(str(logo_path))
            logo_img.set_pixel_size(96)
            logo_box.append(logo_img)

        title_lbl = Gtk.Label()
        title_lbl.set_markup("<span size='xx-large' weight='bold'>LimeOBS</span>")
        logo_box.append(title_lbl)

        sub_lbl = Gtk.Label()
        sub_lbl.set_markup("<span size='medium' alpha='70%'>Öğrenci &amp; Veli Masasüstü İstemcisi</span>")
        logo_box.append(sub_lbl)

        main_box.append(logo_box)

        # 2. Giriş Formu (Grup)
        form_group = Adw.PreferencesGroup()
        form_group.set_title("Giriş Bilgileri")

        from api_bridge import get_saved_base_url, set_base_url

        self.school_url_row = Adw.EntryRow()
        self.school_url_row.set_title("Okul OBS Sunucu Adresi")
        self.school_url_row.set_text(get_saved_base_url())
        self.school_url_row.connect("entry-activated", lambda _: self.tc_row.grab_focus())
        form_group.add(self.school_url_row)

        self.tc_row = Adw.EntryRow()
        self.tc_row.set_title("T.C. Kimlik No")
        self.tc_row.connect("entry-activated", lambda _: self.password_row.grab_focus())
        form_group.add(self.tc_row)

        self.password_row = Adw.PasswordEntryRow()
        self.password_row.set_title("Şifre")
        self.password_row.connect("entry-activated", lambda _: self.on_login_clicked(None))
        form_group.add(self.password_row)

        # 3. Beni Hatırla SwitchRow
        self.remember_me_row = Adw.SwitchRow()
        self.remember_me_row.set_title("Beni Hatırla")
        self.remember_me_row.set_subtitle("Oturumu bilgisayara kaydet")
        self.remember_me_row.set_active(True)
        form_group.add(self.remember_me_row)

        main_box.append(form_group)

        # 4. Hata Mesajı Alanı
        self.error_label = Gtk.Label()
        self.error_label.add_css_class("error-text")
        self.error_label.set_wrap(True)
        self.error_label.set_visible(False)
        main_box.append(self.error_label)

        # 5. Giriş Butonu & Yükleme Spinner'ı
        action_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        self.spinner = Gtk.Spinner()
        self.spinner.set_size_request(24, 24)
        self.spinner.set_visible(False)
        action_box.append(self.spinner)

        self.login_btn = Gtk.Button(label="Giriş Yap")
        self.login_btn.add_css_class("suggested-action")
        self.login_btn.add_css_class("pill")
        self.login_btn.set_size_request(-1, 45)
        self.login_btn.connect("clicked", self.on_login_clicked)
        action_box.append(self.login_btn)

        main_box.append(action_box)

        clamp.set_child(main_box)
        self.append(clamp)

    def on_login_clicked(self, widget):
        from api_bridge import clear_cache, set_base_url
        clear_cache()

        school_url = self.school_url_row.get_text().strip()
        if school_url:
            set_base_url(school_url)

        tc = self.tc_row.get_text().strip()
        password = self.password_row.get_text().strip()

        if not tc or not password:
            self.show_error("Lütfen T.C. Kimlik No ve şifrenizi girin.")
            return

        self.set_loading(True)

        def worker():
            try:
                result = akbim_api.login(tc, password)
                if result.get("success"):
                    if self.remember_me_row.get_active():
                        akbim_api.save_session()
                        from api_bridge import save_credentials
                        save_credentials(tc, password)
                    GLib.idle_add(self.handle_success)
                else:
                    msg = result.get("msg", "Kullanıcı adı veya şifre yanlış.")
                    GLib.idle_add(self.handle_failure, msg)
            except Exception as e:
                GLib.idle_add(self.handle_failure, f"Bağlantı hatası: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def set_loading(self, is_loading):
        self.login_btn.set_sensitive(not is_loading)
        self.tc_row.set_sensitive(not is_loading)
        self.password_row.set_sensitive(not is_loading)
        self.remember_me_row.set_sensitive(not is_loading)
        self.spinner.set_visible(is_loading)
        if is_loading:
            self.spinner.start()
            self.error_label.set_visible(False)
        else:
            self.spinner.stop()

    def show_error(self, message):
        self.error_label.set_text(message)
        self.error_label.set_visible(True)

    def handle_failure(self, error_message):
        self.set_loading(False)
        self.show_error(error_message)

    def handle_success(self):
        self.set_loading(False)
        self.on_login_success()
