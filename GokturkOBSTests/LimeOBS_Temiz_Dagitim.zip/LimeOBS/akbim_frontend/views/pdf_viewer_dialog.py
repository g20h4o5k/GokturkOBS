import os
import math
from pathlib import Path
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Poppler", "0.18")
from gi.repository import Gtk, Adw, GLib, Gio, Gdk, Poppler, cairo


class PdfViewerDialog(Adw.Window):
    """
    LimeOBS Dahili PDF Görüntüleyici
    Sayfalar arası geçiş, Yakınlaştırma (Zoom), Tam Ekran ve Dışa Aktarma destekler.
    """
    def __init__(self, parent_window, pdf_path_or_bytes, title="PDF Görüntüleyici"):
        super().__init__()
        if parent_window:
            self.set_transient_for(parent_window)
            self.set_modal(True)

        self.set_title(title)
        self.set_default_size(880, 800)

        self.pdf_document = None
        self.current_page_idx = 0
        self.total_pages = 0
        self.zoom_level = 1.25  # 125% varsayılan
        self.temp_file_path = None

        # Dokümanı yükle
        self.load_pdf(pdf_path_or_bytes)

        # Arayüzü inşa et
        self.build_ui(title)

    def load_pdf(self, source):
        try:
            if isinstance(source, (bytes, bytearray)):
                import tempfile
                tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
                tmp.write(source)
                tmp.close()
                self.temp_file_path = tmp.name
                file_uri = f"file://{os.path.abspath(tmp.name)}"
            else:
                self.temp_file_path = str(source)
                file_uri = f"file://{os.path.abspath(str(source))}"

            gfile = Gio.File.new_for_uri(file_uri)
            self.pdf_document = Poppler.Document.new_from_gfile(gfile, None)
            self.total_pages = self.pdf_document.get_n_pages() if self.pdf_document else 0
        except Exception as e:
            print(f"PDF yükleme hatası: {e}")
            self.pdf_document = None
            self.total_pages = 0

    def build_ui(self, title):
        main_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        # 1. HeaderBar
        header = Adw.HeaderBar()
        self.title_widget = Adw.WindowTitle(
            title=title,
            subtitle=f"Sayfa {self.current_page_idx + 1} / {max(1, self.total_pages)}" if self.total_pages > 0 else "Hata"
        )
        header.set_title_widget(self.title_widget)

        # Sayfa Gezinme Butonları (Önceki / Sonraki)
        nav_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        
        self.prev_btn = Gtk.Button(icon_name="go-previous-symbolic")
        self.prev_btn.set_tooltip_text("Önceki Sayfa")
        self.prev_btn.connect("clicked", lambda _: self.change_page(-1))
        nav_box.append(self.prev_btn)

        self.page_label = Gtk.Label(label=f"{self.current_page_idx + 1} / {self.total_pages}")
        self.page_label.add_css_class("numeric")
        self.page_label.set_margin_start(4)
        self.page_label.set_margin_end(4)
        nav_box.append(self.page_label)

        self.next_btn = Gtk.Button(icon_name="go-next-symbolic")
        self.next_btn.set_tooltip_text("Sonraki Sayfa")
        self.next_btn.connect("clicked", lambda _: self.change_page(1))
        nav_box.append(self.next_btn)

        header.pack_start(nav_box)

        # Zoom & Dışa Aktar Butonları
        tools_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        zoom_out_btn = Gtk.Button(icon_name="zoom-out-symbolic")
        zoom_out_btn.set_tooltip_text("Uzaklaştır")
        zoom_out_btn.connect("clicked", lambda _: self.change_zoom(-0.2))
        tools_box.append(zoom_out_btn)

        zoom_in_btn = Gtk.Button(icon_name="zoom-in-symbolic")
        zoom_in_btn.set_tooltip_text("Yakınlaştır")
        zoom_in_btn.connect("clicked", lambda _: self.change_zoom(0.2))
        tools_box.append(zoom_in_btn)

        # Dışa Aktar / Sistemde Aç Butonu
        if self.temp_file_path:
            open_ext_btn = Gtk.Button(icon_name="document-open-symbolic")
            open_ext_btn.set_tooltip_text("Sistem PDF Uygulamasında Aç")
            from api_bridge import open_file_external
            open_ext_btn.connect("clicked", lambda _: open_file_external(self.temp_file_path))
            tools_box.append(open_ext_btn)

        header.pack_end(tools_box)
        main_vbox.append(header)

        # 2. PDF Çizim Alanı (Gtk.DrawingArea)
        self.scroll = Gtk.ScrolledWindow()
        self.scroll.set_vexpand(True)
        self.scroll.set_hexpand(True)

        # Çizim alanı
        self.drawing_area = Gtk.DrawingArea()
        self.drawing_area.set_draw_func(self.on_draw)
        self.drawing_area.set_halign(Gtk.Align.CENTER)
        self.drawing_area.set_valign(Gtk.Align.CENTER)
        self.drawing_area.set_margin_top(16)
        self.drawing_area.set_margin_bottom(16)
        self.drawing_area.set_margin_start(16)
        self.drawing_area.set_margin_end(16)

        self.scroll.set_child(self.drawing_area)
        main_vbox.append(self.scroll)

        self.set_content(main_vbox)
        self.update_page_ui()

    def change_page(self, delta):
        if not self.pdf_document or self.total_pages == 0:
            return
        new_page = self.current_page_idx + delta
        if 0 <= new_page < self.total_pages:
            self.current_page_idx = new_page
            self.update_page_ui()
            self.drawing_area.queue_draw()

    def change_zoom(self, delta):
        self.zoom_level = max(0.5, min(3.5, self.zoom_level + delta))
        self.update_page_ui()
        self.drawing_area.queue_draw()

    def update_page_ui(self):
        if not self.pdf_document or self.total_pages == 0:
            self.prev_btn.set_sensitive(False)
            self.next_btn.set_sensitive(False)
            self.page_label.set_text("0 / 0")
            return

        self.prev_btn.set_sensitive(self.current_page_idx > 0)
        self.next_btn.set_sensitive(self.current_page_idx < self.total_pages - 1)
        self.page_label.set_text(f"{self.current_page_idx + 1} / {self.total_pages}")
        self.title_widget.set_subtitle(f"Sayfa {self.current_page_idx + 1} / {self.total_pages} (%{int(self.zoom_level * 100)})")

        # Sayfa boyutuna göre drawing area isteğini güncelle
        page = self.pdf_document.get_page(self.current_page_idx)
        if page:
            w, h = page.get_size()
            self.drawing_area.set_size_request(int(w * self.zoom_level), int(h * self.zoom_level))

    def on_draw(self, area, cr, width, height):
        if not self.pdf_document or self.total_pages == 0:
            cr.set_source_rgb(0.9, 0.2, 0.2)
            cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
            cr.set_font_size(18)
            cr.move_to(50, 50)
            cr.show_text("PDF belgesi yüklenemedi veya bozuk.")
            return

        # Beyaz sayfa zemini ve hafif gölge
        cr.set_source_rgb(1.0, 1.0, 1.0)
        cr.rectangle(0, 0, width, height)
        cr.fill()

        # Sayfayı render et
        page = self.pdf_document.get_page(self.current_page_idx)
        if page:
            cr.save()
            cr.scale(self.zoom_level, self.zoom_level)
            page.render(cr)
            cr.restore()


def open_pdf_viewer(parent_window, pdf_path_or_bytes, title="PDF Görüntüleyici"):
    """Dahili PDF Görüntüleyicisini modal olarak açar."""
    viewer = PdfViewerDialog(parent_window, pdf_path_or_bytes, title)
    viewer.present()
    return viewer
