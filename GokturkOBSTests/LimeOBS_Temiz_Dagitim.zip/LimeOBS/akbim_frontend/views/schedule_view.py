import threading
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib

from api_bridge import get_adaptive_index_data


class ScheduleView(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_vexpand(True)
        self.set_hexpand(True)

        clamp = Adw.Clamp()
        clamp.set_maximum_size(900)

        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.main_box.set_margin_top(20)
        self.main_box.set_margin_bottom(20)
        self.main_box.set_margin_start(16)
        self.main_box.set_margin_end(16)

        header_label = Gtk.Label()
        header_label.set_markup("<span size='large' weight='bold'>📅 Haftalık Ders Programı</span>")
        header_label.set_halign(Gtk.Align.START)
        self.main_box.append(header_label)

        self.days_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.main_box.append(self.days_container)

        clamp.set_child(self.main_box)
        self.set_child(clamp)

    def load_data(self):
        def worker():
            try:
                data = get_adaptive_index_data()
                schedule = data.get("data", {}).get("lessonSchedule", {}).get("data", {})
                x_info = schedule.get("xInfo", [])
                y_info = schedule.get("yInfo", [])
                lessons = schedule.get("data", [])

                GLib.idle_add(self.render_schedule, x_info, y_info, lessons)
            except Exception as e:
                print(f"Ders programı yükleme hatası: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def render_schedule(self, x_info, y_info, lessons):
        from datetime import datetime
        now = datetime.now()
        # Pazartesi: 1, Salı: 2, ... Cuma: 5
        weekday_idx = now.isoweekday()
        now_time = now.time()

        child = self.days_container.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            self.days_container.remove(child)
            child = next_child

        if not lessons or not y_info:
            empty_row = Adw.ActionRow()
            empty_row.set_title("Ders programı bulunamadı.")
            self.days_container.append(empty_row)
            return

        for day_index, day_data in enumerate(y_info, start=1):
            day_name = day_data[0] if len(day_data) > 0 else f"Gün {day_index}"
            day_date = day_data[1] if len(day_data) > 1 else ""
            date_str = f" ({day_date})" if day_date else ""

            is_today = (day_index == weekday_idx)

            day_group = Adw.PreferencesGroup()
            title_prefix = "⭐ " if is_today else ""
            title_suffix = " (Bugün)" if is_today else ""
            day_group.set_title(f"{title_prefix}{day_name}{date_str}{title_suffix}")

            day_lessons = sorted(
                [l for l in lessons if l.get("y") == day_index],
                key=lambda item: item.get("x", 0)
            )

            if not day_lessons:
                no_lesson_row = Adw.ActionRow()
                no_lesson_row.set_title("Bu günde ders bulunmuyor.")
                day_group.add(no_lesson_row)
            else:
                for l in day_lessons:
                    x_idx = l.get("x", 1) - 1
                    slot = x_info[x_idx][0] if 0 <= x_idx < len(x_info) else "??:??"
                    texts = l.get("text", [])
                    teacher = texts[0] if len(texts) > 0 else "-"
                    subject = texts[1] if len(texts) > 1 else "-"
                    
                    header_title = l.get("data", {}).get("headerTitle", "")
                    extra = f" [{header_title}]" if header_title else ""

                    row = Adw.ActionRow()
                    row.set_title(f"{subject}{extra}")
                    row.set_subtitle(f"Saat: {slot}  •  Öğretmen: {teacher}")
                    row.set_icon_name("appointment-soon-symbolic")

                    # Saat aralığı analizi (Örn: 09:00 - 09:40 veya 09:00)
                    if is_today and "-" in slot:
                        try:
                            start_str, end_str = slot.split("-")
                            sh, sm = map(int, start_str.strip().split(":"))
                            eh, em = map(int, end_str.strip().split(":"))
                            from datetime import time
                            st_time = time(sh, sm)
                            end_time = time(eh, em)

                            if st_time <= now_time <= end_time:
                                row.add_css_class("active-lesson-card")
                                badge = Gtk.Label(label="Şu Anki Ders")
                                badge.add_css_class("badge-active")
                                row.add_suffix(badge)
                            elif now_time < st_time:
                                badge = Gtk.Label(label="Sıradaki")
                                badge.add_css_class("badge-upcoming")
                                row.add_suffix(badge)
                        except Exception:
                            pass

                    day_group.add(row)

            self.days_container.append(day_group)
