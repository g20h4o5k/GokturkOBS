from akbim_api import ensure_login, load_index
import pyrebase
import json
import time

if not ensure_login():
    print("Giriş yapılamadı!")
    exit()

config = {
    "apiKey": "AIzaSyAIVMjkQFkfXhQCE-X5iI_5piGgHTr9MR4",
    "authDomain": "akbim-a34b3.firebaseapp.com",
    "databaseURL": "https://firebaseio.com",  # Projenizin veritabanı linki
    "projectId": "akbim-a34b3",
    "storageBucket": "akbim-a34b3.firebasestorage.app",
    "messagingSenderId": "566758594935",
    "appId": "1:566758594935:web:4131006c4838eb7f45e972",
}

firebase = pyrebase.initialize_app(config)
data = load_index()
db = firebase.database()