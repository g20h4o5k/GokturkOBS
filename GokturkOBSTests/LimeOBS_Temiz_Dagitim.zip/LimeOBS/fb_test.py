import pyrebase

config = {
    "apiKey": "AIzaSyAIVMjkQFkfXhQCE-X5iI_5piGgHTr9MR4",
    "authDomain": "akbim-a34b3.firebaseapp.com",
    "databaseURL": "https://akbim-a34b3-default-rtdb.europe-west1.firebasedatabase.app",
    "projectId": "akbim-a34b3",
    "storageBucket": "akbim-a34b3.firebasestorage.app",
}

firebase = pyrebase.initialize_app(config)
db = firebase.database()

db.child("test").set({"merhaba": "dünya"})
print(db.child("test").get().val())