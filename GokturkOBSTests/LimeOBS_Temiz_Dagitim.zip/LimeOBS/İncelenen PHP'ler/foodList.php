<section class="section-account">
    <div class="card">
        <div class="card-head style-primary">
            <header>Yemek Listesi</header>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div id="loader" style="text-align: center;">
                        <i class="fa fa-cog fa-spin fa-4x"></i>
                    </div>
                    <h4 style="display: none;" id="viewHeader"><a href="" target="_blank" id="viewLink"><i class="md-pageview"></i> Eğer dosya görüntülenmezse burayı tıklayın.</a></h4><br />
                    <h4 style="display: none;" id="downloadHeader"><a href="" target="_blank" id="downloadLink"><i class="md-file-download"></i> Dosyayı indirmek için burayı tıklayın.</a></h4>
                    <object id="obj" style="display: none;" data="" type="application/pdf" width="100%" height="1100">
                    </object>
                    <div class="alert alert-callout alert-warning" role="alert" style="display: none;" id="empty">
                        <strong>Maalesef!</strong> Bulunduğunuz kurum tarafından henüz yemek listesi dosyası yüklenmemiş.
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">$(document).ready(function(){callAjax({request:"get-food-list"},{url:"pages/student/require/foodListAction.php"},function(i){if(i.hash!==""){var e="download.php?file="+i.hash;$("#viewLink").attr("href",e+"&view"),$("#viewHeader").css("display","inline-block"),$("#downloadLink").attr("href",e),$("#downloadHeader").css("display","inline-block"),$("#obj").attr("data",e+"&view").css("display","inline-block"),$("input").val("")}else $("#empty").css("display","block");$("#loader").css("display","none")},function(){toastr.clear(),toastr.info("Y\xFCkleniyor.")},null,null)});
</script>
