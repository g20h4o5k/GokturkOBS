<script src="assets/js/other/oauthFuncs.js"></script>
<style>.badge-success{background-color:#4caf50;color:#fff}
</style>

<section>
    <div class="row">
        <div id="mainDiv" class="col-lg-12 col-sm-12">
            <div class="card">
                <div class="card-head card-head-lg style-primary">
                    <header>Kullanıcı Profili</header>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6 col-sm-6">
                            <h3 class="text-light"><i class="md md-school text-accent-dark"></i> Öğrenci <strong>Bilgileri</strong></h3>
                            <div class="row clearfix">
                                <div style="float:left;">
                                    <img style="width:200px; height:250px; border-radius: 20px;" src="studentPhoto.php?hash=YUx6MHJTN09KNHB2bzNtN2pZNWU3dz09&ts=1791027532">
                                </div>
                                <div style="float:left;">
                                    <dl class="dl-horizontal">
                                        <dt>Öğrenci Numara</dt>
                                        <dd>20669</dd>                                        
                                        <dt>Kayıt Programı</dt>
                                        <dd>7</dd>
                                        <dt>Kayıt Türü</dt>
                                        <dd>7. </dd>
                                        <dt>Sınıf Kodu</dt>
                                        <dd>K-7-E</dd>
                                        <dt>İsim Soyisim</dt>
                                        <dd>KAĞAN EFE TOPÇU</dd>
                                    </dl>
                                </div>

                            </div>
                            <h3 class="text-light"><i class="md md-person text-accent-dark"></i> Veli <strong>Bilgileri</strong></h3>
                            <dl class="dl-horizontal">                                
                                <dt>İsim Soyisim</dt>
                                <dd>SERKAN TOPÇU</dd>
                            </dl>
                        </div>
                        <div class="col-lg-6 col-sm-6">
                            <div class="card tabs-right style-default-light">
                                <div class="card-head">
                                    <header class="text-accent-dark"><i class="fa fa-cogs"></i> Hesap Ayarları</header>
                                </div>
                                <ul class="card-head nav nav-tabs text-center tabs-accent-dark" data-toggle="tabs">
                                    <li class="active"><a href="#changePassword"><i class="md md-vpn-key text-accent-dark"></i><br /><h4>ŞİFRE<br><small>Şifre değiştirme</small></h4></a></li>
                                    <li class=""><a href="#changeEmail"><i class="md md-mail text-accent-dark"></i><br /><h4>EMAIL<br><small>Email güncelleme</small></h4></a></li>
                                </ul>
                                <div class="card-body tab-content style-default-bright">
                                    <div class="tab-pane active" id="changePassword">
                                        <h3 class="text-light"><i class="md md-vpn-key text-accent-dark"></i> Şifre <strong>Değiştirme</strong></h3>
                                        <form class="form" id="passwordForm" onsubmit="return false;">
                                            <div class="form-group floating-label">
                                                <input type="password" name="password" class="form-control" id="password" maxlength="30">
                                                <label for="password">Mevcut şifre</label>
                                            </div>
                                            <div class="form-group floating-label">
                                                <input type="password" name="passwordNew" class="form-control" id="passwordNew" maxlength="30">
                                                <label for="passwordNew">Yeni şifre</label>
                                            </div>
                                            <div class="form-group floating-label">
                                                <input type="password" name="passwordReNew" class="form-control" id="passwordReNew" maxlength="30">
                                                <label for="passwordReNew">Yeni şifre tekrar</label>
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-block ink-reaction btn-primary submit">GÜNCELLE <i class="fa fa-cog fa-spin loader" style="display: none;"></i><i class="md md-save icon"></i></button>
                                            </div>
                                            <input type="hidden" name="request" value="editPassword">
                                        </form>
                                    </div>
                                    <div class="tab-pane" id="changeEmail">
                                        <h3 class="text-light"><i class="md md-mail text-accent-dark"></i> Email <strong>Güncelleme</strong></h3>
                                        <form class="form" id="emailForm" onsubmit="return false;">
                                            <div class="form-group floating-label">
                                                <input type="password" name="password" class="form-control" id="email" maxlength="30">
                                                <label for="email">Mevcut şifre</label>
                                            </div>
                                            <div class="form-group floating-label">
                                                <input type="text" name="emailNew" class="form-control" id="emailNew" maxlength="50">
                                                <label for="emailNew">Yeni email</label>
                                            </div>
                                            <div class="form-group floating-label">
                                                <input type="text" name="emailReNew" class="form-control" id="emailReNew" maxlength="50">
                                                <label for="emailReNew">Yeni email tekrar</label>
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-block ink-reaction btn-primary submit">GÜNCELLE <i class="fa fa-cog fa-spin loader" style="display: none;"></i><i class="md md-save icon"></i></button>
                                            </div>
                                            <input type="hidden" name="request" value="editEmail">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">$(document).ready(function(){renderProviderList($("#mainDiv")),$("#passwordForm").submit(function(){var s=$("#password").val(),i=$("#passwordNew").val(),a=$("#passwordReNew").val();if(s==""||i==""||a=="")toastr.warning("Bo\u015F alan b\u0131rakt\u0131n\u0131z.");else if(i.length<6)toastr.warning("Yeni \u015Fifreniz en az 6 haneli olmal\u0131d\u0131r.");else if(i.length>30)toastr.warning("Yeni \u015Fifreniz en fazla 30 haneli olabilir.");else if(i!=a)toastr.warning("\u015Eifreleriniz e\u015Fle\u015Fmiyor.");else{var n=new FormData($(this)[0]);$.ajax({type:"POST",url:"pages/student/require/changePassword.php",data:n,cache:!1,contentType:!1,processData:!1,success:function(e){e=="requestDenied"?toastr.warning("Ancak 1 saatte 1 kere \u015Fifre de\u011Fi\u015Fikli\u011Fi yapabilirsiniz."):e=="empty"?toastr.warning("Bo\u015F alan b\u0131rakt\u0131n\u0131z."):e=="wrongPassword"?toastr.warning("\u015Eifrenizi yanl\u0131\u015F girdiniz."):e=="shortPass"?toastr.warning("Yeni \u015Fifreniz en az 6 haneli olmal\u0131d\u0131r."):e=="longPass"?toastr.warning("Yeni \u015Fifreniz en fazla 30 haneli olabilir."):e=="notEqual"?toastr.warning("\u015Eifreleriniz e\u015Fle\u015Fmiyor."):e=="samePass"?toastr.warning("Yeni \u015Fifreniz mevcut olanla ayn\u0131."):e=="success"?toastr.success("\u015Eifreniz ba\u015Far\u0131yla de\u011Fi\u015Ftirildi."):toastr.error("Bir hata olu\u015Ftu."),$(".submit").prop("disabled",!1),$(".loader").css("display","none"),$(".icon").css("display","inline-block")},beforeSend:function(){toastr.clear(),$(".submit").prop("disabled",!0),$(".icon").css("display","none"),$(".loader").css("display","inline-block")},error:function(){$(".submit").prop("disabled",!1),$(".loader").css("display","none"),$(".icon").css("display","inline-block")}})}}),$("#emailForm").submit(function(){var s=$("#email").val(),i=$("#emailNew").val(),a=$("#emailReNew").val();if(s==""||i==""||a=="")toastr.warning("Bo\u015F alan b\u0131rakt\u0131n\u0131z.");else if(i.length>50)toastr.warning("Yeni emailiniz en fazla 50 haneli olabilir.");else if(i!=a)toastr.warning("Email hesaplar\u0131n\u0131z e\u015Fle\u015Fmiyor.");else{var n=new FormData($(this)[0]);$.ajax({type:"POST",url:"pages/student/require/changeEmail.php",data:n,cache:!1,contentType:!1,processData:!1,success:function(e){e=="requestDenied"?toastr.warning("Ancak 1 saatte 1 kere email de\u011Fi\u015Fikli\u011Fi yapabilirsiniz."):e=="empty"?toastr.warning("Bo\u015F alan b\u0131rakt\u0131n\u0131z."):e=="wrongPassword"?toastr.warning("\u015Eifenizi yanl\u0131\u015F girdiniz."):e=="notAnEmail"?toastr.warning("Hatal\u0131 email."):e=="longEmail"?toastr.warning("Yeni \u015Fifreniz en fazla 50 haneli olabilir."):e=="notEqual"?toastr.warning("Email hesaplar\u0131n\u0131z e\u015Fle\u015Fmiyor."):e=="sameEmail"?toastr.warning("Yeni email hesab\u0131n\u0131z mevcut olanla ayn\u0131."):e=="success"?toastr.success("Email hesab\u0131n\u0131z ba\u015Far\u0131yla de\u011Fi\u015Ftirildi."):toastr.error("Bir hata olu\u015Ftu."),$(".submit").prop("disabled",!1),$(".loader").css("display","none"),$(".icon").css("display","inline-block")},beforeSend:function(){toastr.clear(),$(".submit").prop("disabled",!0),$(".icon").css("display","none"),$(".loader").css("display","inline-block")},error:function(){$(".submit").prop("disabled",!1),$(".loader").css("display","none"),$(".icon").css("display","inline-block")}})}})});
</script>
